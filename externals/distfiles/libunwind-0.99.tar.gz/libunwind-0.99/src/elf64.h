#ifndef elf64_h
#define elf64_h

#define ELF_CLASS	ELFCLASS64
#include "elfxx.h"

#endif /* elf64_h */
