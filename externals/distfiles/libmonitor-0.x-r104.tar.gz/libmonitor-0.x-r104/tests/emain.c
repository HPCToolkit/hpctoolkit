/*
 * Main program to link with libearly.so.
 *
 * $Id: emain.c 103 2009-03-10 22:44:00Z krentel $
 */

#include <stdio.h>
#include <unistd.h>

void early_fcn(void);

int
main(int argc, char **argv)
{
    printf("==> main begin\n");
    sleep(2);
    early_fcn();
    sleep(2);
    printf("==> main end\n");

    return (0);
}
