/*
 *  Libmonitor Fortran MPI override functions.
 *
 *  mpi_init --> mpi_init_
 *
 *  $Id: mpi_f1.c 39 2008-01-30 18:30:36Z krentel $
 */

#define FORTRAN_NAME(name)  name ## _
#define FORTRAN_REAL_NAME(name)  __real_ ## name ## _

#include "mpi_fortran.h"
