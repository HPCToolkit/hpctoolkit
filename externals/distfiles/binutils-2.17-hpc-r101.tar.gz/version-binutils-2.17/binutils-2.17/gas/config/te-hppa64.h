#define TARGET_ARCH_SIZE 64

/* Labels are not required to have a colon for a suffix.  */
#define LABELS_WITHOUT_COLONS 1

#include "obj-format.h"
