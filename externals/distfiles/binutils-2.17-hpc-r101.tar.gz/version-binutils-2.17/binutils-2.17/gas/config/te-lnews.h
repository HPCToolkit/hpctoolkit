/* te-lnews.h -- little-endian NEWS emulation.  */

#define ECOFF_LITTLE_FORMAT "ecoff-biglittlemips"

#include "obj-format.h"
