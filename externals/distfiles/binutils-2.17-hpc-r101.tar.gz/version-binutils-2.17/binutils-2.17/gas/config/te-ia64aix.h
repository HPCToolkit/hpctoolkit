#define TE_AIX50
#define LOCAL_LABELS_FB 1

#include "obj-format.h"
