/*BEGIN_LEGAL 
Intel Open Source License 

Copyright (c) 2002-2007 Intel Corporation 
All rights reserved. 
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

Redistributions of source code must retain the above copyright notice,
this list of conditions and the following disclaimer.  Redistributions
in binary form must reproduce the above copyright notice, this list of
conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.  Neither the name of
the Intel Corporation nor the names of its contributors may be used to
endorse or promote products derived from this software without
specific prior written permission.
 
THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE INTEL OR
ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
END_LEGAL */


#ifndef PINTOOL_THREADLIB_H
#define PINTOOL_THREADLIB_H

#if !defined(TARGET_WINDOWS)

#include <sched.h>
#include <sys/types.h>
#include <signal.h>
#include <unistd.h>
#include <pthread.h>
#define EXPORT_SYM 
typedef void *(*LPTHREAD_START_ROUTINE)(
    void * lpThreadParameter
    );
typedef pthread_t THREAD_HANDLE;
typedef int BOOL;
#define TRUE 1
#define FALSE 0

#else //defined(TARGET_WINDOWS)

#include <windows.h>
#define EXPORT_SYM __declspec( dllexport ) 
// LPTHREAD_START_ROUTINE comes from windows.h
typedef HANDLE THREAD_HANDLE;

#endif

#include <stdio.h>
#include <assert.h>

#define MAXTHREADS 1000

EXPORT_SYM
BOOL CreateOneThread(LPTHREAD_START_ROUTINE threadStart, THREAD_HANDLE *handle);

EXPORT_SYM
BOOL JoinOneThread(THREAD_HANDLE threadHandle);

#endif  // #ifndef PINTOOL_THREADLIB_H
