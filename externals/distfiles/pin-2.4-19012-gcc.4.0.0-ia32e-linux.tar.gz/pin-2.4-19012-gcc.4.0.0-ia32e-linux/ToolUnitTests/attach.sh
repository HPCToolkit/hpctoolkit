#! /bin/sh
rm -f pin_attached fini.out
touch fini.out
./attach &
$1 -pid $! -mt 0 -t fini.so
touch pin_attached
wait

