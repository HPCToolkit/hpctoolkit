#define TE_WINCE
#include "te-pe.h"
