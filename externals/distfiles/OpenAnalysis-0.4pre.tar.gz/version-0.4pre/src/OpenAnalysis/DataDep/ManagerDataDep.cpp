#include "ManagerDataDep.hpp"

namespace OA {
namespace DataDep {

ManagerDataDep::ManagerDataDep(OA_ptr<DataDepIRInterface> _ir) :
    mIR(_ir)
{
}

} } // end namespaces

