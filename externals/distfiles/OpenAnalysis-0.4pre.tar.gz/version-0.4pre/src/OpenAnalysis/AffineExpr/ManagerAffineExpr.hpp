#ifndef ManagerAffineExpr_H
#define ManagerAffineExpr_H

#include <OpenAnalysis/ExprTree/ExprTreeVisitor.hpp>
#include <OpenAnalysis/IRInterface/AffineExprIRInterface.hpp>
#include <OpenAnalysis/AffineExpr/AffineExprAbstraction.hpp>
#include <OpenAnalysis/Alias/Interface.hpp>
#include <stack>
using namespace std;

namespace OA {
namespace AffineExpr {

/*! Used by ManagerAffineExpr to build affine expressions.  This class
    traverses the nodes in an expression tree parsing out the needed
    information to make an affine expression.  Performs a prefix traversal. */
class AffineExprExprTreeVisitor : public ExprTreeVisitor {
  public:
    AffineExprExprTreeVisitor(
        OA_ptr<AffineExprAbstraction> afExp,
        OA_ptr<AffineExprIRInterface> ir,
        OA_ptr<Alias::Interface> aliasResults)
        :
        mAfExp(afExp),
        mIR(ir),
        mAliasResults(aliasResults)
    {
    }

    virtual ~AffineExprExprTreeVisitor() {}

    virtual void visitExprTreeBefore(ExprTree&);
    virtual void visitExprTreeAfter(ExprTree&);

    virtual void visitNode(ExprTree::Node& n);
    virtual void visitOpNode(ExprTree::OpNode& n);
    virtual void visitCallNode(ExprTree::CallNode& n);
    virtual void visitMemRefNode(ExprTree::MemRefNode& n);
    virtual void visitConstSymNode(ExprTree::ConstSymNode& n);
    virtual void visitConstValNode(ExprTree::ConstValNode& n);

  private:
    void pushVar(OA_ptr<NamedLoc> var);
    void pushScaler(int val);
    void factor();
    void term();

    stack<OA_ptr<NamedLoc> > mVars;
    stack<int> mScalers;

    OA_ptr<AffineExprAbstraction> mAfExp;
    OA_ptr<AffineExprIRInterface> mIR;
    OA_ptr<Alias::Interface> mAliasResults;
};

/*! The affine expression manager is responsible for constructing affine
    expression objects. */
class ManagerAffineExpr {
  public:
    ManagerAffineExpr(
        OA_ptr<AffineExprIRInterface> _ir,
        OA_ptr<Alias::Interface> aliasResults);

    /*! given an expression tree construct an affine expression object.
        Analogous to performAnalysis() in most managers. */
    // !!! will need alias analysis results
    // !!! will need loop detection results.
    OA_ptr<AffineExprAbstraction> exprTreeToAffineExpr(ExprTree &eTree);

  private:
    OA_ptr<AffineExprIRInterface> mIR;
    OA_ptr<Alias::Interface> mAliasResults;
};

} } // end namespaces

#endif
