#include "ManagerAffineExpr.hpp"

namespace OA {
namespace AffineExpr {

ManagerAffineExpr::ManagerAffineExpr(
    OA_ptr<AffineExprIRInterface> _ir,
    OA_ptr<Alias::Interface> aliasResults)
    :
    mIR(_ir),
    mAliasResults(aliasResults)
{
}

OA_ptr<AffineExprAbstraction> ManagerAffineExpr::exprTreeToAffineExpr(
    ExprTree &e)
{
    OA_ptr<AffineExprAbstraction> afnExp;
    afnExp = new AffineExprAbstraction();

    AffineExprExprTreeVisitor visitor(afnExp, mIR, mAliasResults);
    e.acceptVisitor(visitor);

    return afnExp;
}

void AffineExprExprTreeVisitor::visitExprTreeBefore(ExprTree& e) { }

void AffineExprExprTreeVisitor::visitExprTreeAfter(ExprTree& e) { }

void AffineExprExprTreeVisitor::visitNode(ExprTree::Node& n) {
    cout << "VisitNode" << endl;
}

void AffineExprExprTreeVisitor::visitOpNode(ExprTree::OpNode& n) {
    cout << "OpNode: " << mIR->toString(n.getHandle()) << endl;

    // iterate over children
    for(int i = 0; i < n.num_children(); i++) {
        ExprTree::ChildNodesIterator iterChildren(n);

        for(; iterChildren.isValid(); ++iterChildren) {
            OA_ptr<ExprTree::Node> child;
            child = iterChildren.current();
            child->acceptVisitor(*this);
        }
    }

    // determine what to do based on the type of operator
    OpHandle hOp = n.getHandle();
    switch(mIR->getOpType(hOp)) {
        case OP_ADD:
            term();
            break;

        case OP_SUBTRACT:
            assert(false);
            break;

        case OP_MULTIPLY:
            factor();
            break;

        case OP_DIVIDE:
            assert(false);
            break;

        case OP_MODULO:
            assert(false);
            break;

        default:
            assert(false);
            break;
    }
}

void AffineExprExprTreeVisitor::visitCallNode(ExprTree::CallNode& n) {
    cout << "CallNode" << endl;
}

void AffineExprExprTreeVisitor::visitMemRefNode(ExprTree::MemRefNode& n) {
    cout << "MemRefNode: " << mIR->toString(n.getHandle()) << endl;

    OA_ptr<LocIterator> locs;
    MemRefHandle hMemRef = n.getHandle();
    locs = mAliasResults->getMayLocs(hMemRef);
    OA_ptr<Location> loc = locs->current();
    OA_ptr<NamedLoc> var = loc.convert<NamedLoc>();
    var->output(*mIR);

    mVars.push(var);
    //OA_ptr<MemRefExprIterator> iterMRE = mIR->getMemRefExprIterator(hMemRef);


/*    for(; iterMRE->isValid(); ++(*iterMRE)) {
        OA_ptr<MemRefExpr> mre = iterMRE->current();

        if(mre->isaNamed()) {
            // convert the MRE into a MemRefHandle
            OA_ptr<NamedRef> namedRef;
            namedRef = mre.convert<NamedRef>();
            SymHandle hSym = namedRef->getSymHandle();
            MemRefHandle hMemRef = mIR->getSymMemRefHandle(hSym);

            // use aliasing information to get a named location
            OA_ptr<LocIterator> locs;
            locs = mAliasResults->getMayLocs(hMemRef);
            OA_ptr<Location> loc = locs->current();*
            OA_ptr<NamedLoc> var = loc.convert<NamedLoc>();
            var->output(*mIR);

            mVars.push(var);
            break;
        }
    }*/
}

void AffineExprExprTreeVisitor::visitConstSymNode(ExprTree::ConstSymNode& n) {
    cout << "ConstSym" << endl;
}

void AffineExprExprTreeVisitor::visitConstValNode(ExprTree::ConstValNode& n) {
    int val = mIR->constValIntVal(n.getHandle());
    mScalers.push(val);
}

void AffineExprExprTreeVisitor::pushVar(OA_ptr<NamedLoc> var) {
    mVars.push(var);
}

void AffineExprExprTreeVisitor::pushScaler(int val) {
    mScalers.push(val);
}

void AffineExprExprTreeVisitor::factor() {
    mAfExp->addTerm(mVars.top(), mScalers.top());
    mVars.pop();
    mScalers.pop();
}

void AffineExprExprTreeVisitor::term() {
    // if a term is being pushed where there's nothing on the vars stack
    // and one thing on the vals stack then it's the affine expressions
    // offset.

    if(mVars.empty() && mScalers.size() == 1) {
        mAfExp->setOffset(mScalers.top());
        mScalers.pop();
    }
}

} } // end namespaces

