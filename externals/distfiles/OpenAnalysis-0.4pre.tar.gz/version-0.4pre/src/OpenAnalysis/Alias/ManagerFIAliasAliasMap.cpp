/*! \file
  
  \brief The AnnotationManager that generates AliasMaps in a
         context and flow insensitive way

  \authors Michelle Strout, Brian White
  \version $Id: ManagerFIAlias.cpp,v 1.1.2.20 2006/01/18 15:38:41 mstrout Exp $

  Copyright (c) 2002-2005, Rice University <br>
  Copyright (c) 2004-2005, University of Chicago <br>
  Copyright (c) 2006, Contributors <br>
  All rights reserved. <br>
  See ../../../Copyright.txt for details. <br>
*/

#include "ManagerFIAliasAliasMap.hpp"
#include <Utils/Util.hpp>


namespace OA {
  namespace Alias {

static bool debug = false;

/*!
*/
ManagerFIAliasAliasMap::ManagerFIAliasAliasMap(OA_ptr<AliasIRInterface> _ir) 
   : ManagerFIAlias(_ir)
{
    OA_DEBUG_CTRL_MACRO("DEBUG_ManagerFIAliasAliasMap:ALL", debug);
}

OA_ptr<Alias::InterAliasMap> 
ManagerFIAliasAliasMap::performAnalysis( OA_ptr<IRProcIterator> procIter)
{
    // create an empty InterAliasMap
    mInterAliasMap = new InterAliasMap();

    // Invoke the ManagerFIAlias routine to create the alias sets
    // within the union-find universe.
    OA_ptr<UnionFindUniverse> ufset = performFIAlias(procIter);

    // Convert the uion-find universe to equiv sets.
    buildAliasMaps(ufset,procIter);

    return mInterAliasMap;
}


void
ManagerFIAliasAliasMap::buildAliasMaps( OA_ptr<UnionFindUniverse> ufset,
                                        OA_ptr<IRProcIterator> procIter )
{
    if (debug) { std::cout << "=========== Building AliasMap ========" 
                           << std::endl; }

    /////////////// build AliasMap
    std::map<ProcHandle, std::map<int,int> > setIdToNumLocs;
    std::map<ProcHandle, std::map<int,int> > setIdToAliasMapId;
    std::map<ProcHandle, std::map<int,bool> > foundNonVisibleRef;
    std::map<ProcHandle, std::map<int,bool> > foundVisibleFixedLoc;
    std::map<int,std::set<OA_ptr<MemRefExpr> > > ufSetToMREs;
    std::set<int> allufsetIDs;

    // loop all the mres and get a set of mres for each ufset
    std::map<OA_ptr<MemRefExpr>,int>::iterator mreMapIter;
    for (mreMapIter=mMREToID.begin(); mreMapIter!=mMREToID.end();
         mreMapIter++ )
    {
        OA_ptr<MemRefExpr> mre = mreMapIter->first;

        // only map those MREs that do not involve an addressOf operation
        //if (mre->hasAddressTaken()) { continue; }
        if(mre->isaRefOp()) {
           OA_ptr<RefOp> refop = mre.convert<RefOp>();
           if(refop->isaAddressOf()) { continue; }
        }
 
        int setID = ufset->Find(mMREToID[mre]);
        // record which mres are associated with this ufset
        ufSetToMREs[setID].insert(mre);
        allufsetIDs.insert(setID);
        
    }

    // iterate over all procedures and determine the set of fixed
    // locations for each set within each procedure
    for (procIter->reset();  procIter->isValid(); (*procIter)++ ) {
      ProcHandle proc = procIter->current();
      if (debug) {
        std::cout << "proc = " << mIR->toString(proc) << std::endl;
      }

      // initialize various flags and counters for this procedure
      // and all ufsetIDs
      for (std::set<int>::iterator setIter=allufsetIDs.begin();
           setIter!=allufsetIDs.end(); setIter++)
      {
          foundVisibleFixedLoc[proc][*setIter] = false;
          foundNonVisibleRef[proc][*setIter] = false;
          setIdToNumLocs[proc][*setIter] = 0;
      }
      
      // create an alias map for this procedure
      OA_ptr<AliasMap> aliasMap;
      aliasMap = new AliasMap(proc);

      // visit all of the MREs in the program being analyzed
      for (mreMapIter=mMREToID.begin(); mreMapIter!=mMREToID.end();
           mreMapIter++ )
      {
          OA_ptr<MemRefExpr> mre = mreMapIter->first;
          if (debug) {
              std::cout << "\tmre = ";
              mre->dump(std::cout);
              mre->output(*mIR);
          }
          
          if(mre->isaAddressOf()) {
              if (debug) {
                  std::cout << "\taddressOf so skipping this MRE" << std::endl;
              }
              continue; 
          }
 
          int ufsetID = ufset->Find(mMREToID[mre]);
          if (debug) {
              std::cout << "\tufsetID = " << ufsetID << std::endl;
          }

          // if the base is visible then could be a FixedLoc,
          // InvisibleLoc, or just a MRE involving a deref to a
          // visible variable or UnnamedLoc
          VisibleBaseVisitor mreVisitor(mIR, proc);
          mre->acceptVisitor(mreVisitor);
          if (mreVisitor.isBaseVisible()) {

            if (debug) {
              std::cout << "\tmre has a visible base" << std::endl;
            }
            
            // if no alias map set yet then make one
            if (setIdToAliasMapId[proc].find(ufsetID)
                ==setIdToAliasMapId[proc].end() )
            {
              setIdToAliasMapId[proc][ufsetID] = aliasMap->makeEmptySet();
            } 
            int aliasMapSetId = setIdToAliasMapId[proc][ufsetID];

            // Determine if the MRE is a fixed location
            FixedLocationVisitor visitor(mIR, proc, aliasMap);
            mre->acceptVisitor(visitor);
            OA_ptr<LocSetIterator> locSetIterPtr = 
                visitor.getDirectRefLocIterator();

            // if found a fixed location 
            if (locSetIterPtr->isValid()) {
                foundVisibleFixedLoc[proc][ufsetID] = true;

                // put all the fixed locations into the locset
                for (; locSetIterPtr->isValid(); ++(*locSetIterPtr) ) {
                  OA_ptr<Location> directRefLoc = (locSetIterPtr->current());
                  if (debug) {
                      std::cout << "Location: directRefLoc = ";
                      directRefLoc->output(*mIR);
                  }
          
                  aliasMap->addLocation( directRefLoc, aliasMapSetId );
                  
                  if(directRefLoc->isaSubSet()) {
                     OA_ptr<LocSubSet> locSubSet;
                     locSubSet = directRefLoc.convert<LocSubSet>();          
                     OA_ptr<Location> baseLoc;
                     baseLoc = locSubSet->getBaseLoc();
                     aliasMap->removeBaseLoc(baseLoc, aliasMapSetId );
                  } 
                }

            // did not find a fixed location so see if we have an invisible
            } else {
                InvisibleLocationVisitor invVisitor(mIR, proc, 
                                                    mProcToFormalSet[proc]);
                mre->acceptVisitor(invVisitor);

                if (invVisitor.isInvisibleRef()) {
                    OA_ptr<Location> visitorloc 
                         = invVisitor.getInvisibleRefLoc();
                    
                    if (debug) {
                        std::cout << "Location: invloc = ";
                        visitorloc->output(*mIR);
                    }

                    /**************************************************/

                    //! Following logic for InvisibleLoc is used to 
                    //  ensure two MemRefExprs in the same set that only 
                    //  differs with respect to accuracy i.e. (one shows
                    //  up as SubSetRef and other as
                    //  NamedRef) are mapped to the same location.
                    //
                    //  Priya,  what is going on in the logic below?
                    //
                    OA_ptr<InvisibleLoc> invloc 
                         = visitorloc.convert<InvisibleLoc>();
                    OA_ptr<MemRefExpr> inv_memref 
                         = invloc->getMemRefExpr();
                    
                    if(inv_memref->isaRefOp()) {
                        OA_ptr<RefOp> ref 
                            = inv_memref.convert<RefOp>();
                        
                        if(ref->isaSubSetRef()) {

                            OA_ptr<MemRefExpr> inv_memref_clone;
                            inv_memref_clone = ref->getMemRefExpr(); 
                            
                            aliasMap->removeInvisibleLocs(aliasMapSetId,
                                                          inv_memref_clone);
                            OA_ptr<InvisibleLoc> invloc_clone;
                            invloc_clone = new InvisibleLoc(inv_memref);
                            aliasMap->addLocation( invloc_clone, aliasMapSetId );
                        } else {
                            
                            OA::OA_ptr<OA::SubSetRef> subset_mre;
                            OA::OA_ptr<OA::MemRefExpr> nullMRE;
                            OA::OA_ptr<OA::MemRefExpr> composed_mre;

                            subset_mre = new OA::SubSetRef(
                                                   OA::MemRefExpr::USE,
                                                   nullMRE
                                                  );

                            OA_ptr<MemRefExpr> inv_memref_clone;
                            
                            inv_memref_clone
                                = subset_mre->composeWith(inv_memref->clone());

                            if(!(aliasMap->isPartial(aliasMapSetId,
                                        inv_memref_clone))) {
                                
                               OA_ptr<InvisibleLoc> invloc_clone;
                               invloc_clone = new InvisibleLoc(inv_memref);
                               aliasMap->addLocation( invloc_clone, aliasMapSetId );

                            } else {
                               // do not add Location
                            }

                        }    
                        
                     } else {

                            OA::OA_ptr<OA::SubSetRef> subset_mre;
                            OA::OA_ptr<OA::MemRefExpr> nullMRE;
                            OA::OA_ptr<OA::MemRefExpr> composed_mre;

                            subset_mre = new OA::SubSetRef(
                                                   OA::MemRefExpr::USE,
                                                   nullMRE
                                                  );


                            OA_ptr<MemRefExpr> inv_memref_clone;
                            inv_memref_clone
                                = subset_mre->composeWith(inv_memref->clone());


                        if(!(aliasMap->isPartial(aliasMapSetId,
                                        inv_memref_clone))) {
                            OA_ptr<InvisibleLoc> invloc_clone;
                            invloc_clone = new InvisibleLoc(inv_memref);
                            aliasMap->addLocation( invloc_clone, aliasMapSetId );

                        } else {
                           // do not add Location
                        }
 
                     }
                }
                
            } 

            // whether we found a location for this mre or not
            // map this mre to the aliasMapSet 
            // the base of the memrefexpr is visible in this procedure
            if (setIdToAliasMapId[proc].find(ufsetID)
                !=setIdToAliasMapId[proc].end() )
            {
                int aliasMapSetId = setIdToAliasMapId[proc][ufsetID];
                aliasMap->mapMemRefToMapSet(mre, 
                                            setIdToAliasMapId[proc][ufsetID]);
            }

          // If the base is not visible then we need to keep any invisible
          // locs that are found in the same ufset
          } else {

              foundNonVisibleRef[proc][ufsetID] = true;
          }

      } // loop over MREs in program being analyzed

      // do some cleanup wrt to InvisibleLocs
      // for each ufset, remove all of the InvisibleLocs
      // if there was no invisible references but
      // there was a visible fixed location
      for (std::set<int>::iterator setIter=allufsetIDs.begin();
           setIter!=allufsetIDs.end(); setIter++)
      {
          if (foundVisibleFixedLoc[proc][*setIter] == true
              && foundNonVisibleRef[proc][*setIter] == false )
          {
            int aliasMapSetId = setIdToAliasMapId[proc][*setIter];
            aliasMap->removeInvisibleLocs(aliasMapSetId);
          }
      }
 
      // store off the aliasmap for this procedure
      mInterAliasMap->mapProcToAliasMap(proc,aliasMap);

    } // iterate over all procedures

    // iterate over all of the mem ref handles
    // with the goal being to map the mem ref handles to alias sets
    std::map<MemRefHandle,ProcHandle>::iterator refprocIter;
    for (refprocIter=mMemRefHandleToProc.begin();
         refprocIter!=mMemRefHandleToProc.end(); refprocIter++ )
    {
        MemRefHandle memref = refprocIter->first;
        ProcHandle proc = refprocIter->second;

        // get alias map for this procedure
        OA_ptr<AliasMap> aliasMap = mInterAliasMap->getAliasMapResults(proc);

        // loop over MREs for the given memref
        OA_ptr<MemRefExprIterator> mreIterPtr 
            = mIR->getMemRefExprIterator(memref);
      
        // for each mem-ref-expr associated with this memref
        for (; mreIterPtr->isValid(); (*mreIterPtr)++) {
            OA_ptr<OA::MemRefExpr> mre = mreIterPtr->current();

            // only map those MREs that do not involve an addressOf operation
            // if (mre->hasAddressTaken()) { continue; }
            if(mre->isaRefOp()) {
               OA_ptr<RefOp> refop = mre.convert<RefOp>();
               if(refop->isaAddressOf()) { continue; }
            }

            // map the mem ref handle to the set that mre is in
            int ufsetID = ufset->Find(mMREToID[mre]);

            // if we have no location associated with this
            // ufsetID within this proc, then there won't be an
            // alias map associated with it yet
            // therefore we need to map this mre and memrefhandle
            // to the zeroth AliasMap set and store that information
            // for this ufsetID and proc
            if (setIdToAliasMapId[proc].find(ufsetID)
                ==setIdToAliasMapId[proc].end() )
            {
                setIdToAliasMapId[proc][ufsetID] = 0;
            }

            // now assign the memref to the set within the alias map.
            aliasMap->mapMemRefToMapSet(memref, 
                                        setIdToAliasMapId[proc][ufsetID] );

        }  // over mres
    } // over memrefhandles

   }

  } // end of namespace Alias
} // end of namespace OA
