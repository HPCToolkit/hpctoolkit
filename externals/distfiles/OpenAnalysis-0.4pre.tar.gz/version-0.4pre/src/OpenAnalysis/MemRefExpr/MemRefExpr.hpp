/*! \file
  
  \brief Declarations for the MemRefExpr abstraction.

  \authors Michelle Strout, Andy Stone
  \version $Id: MemRefExpr.hpp,v 1.17.6.7 2005/11/04 16:24:12 mstrout Exp $

  Copyright (c) 2002-2005, Rice University <br>
  Copyright (c) 2004-2005, University of Chicago <br>
  Copyright (c) 2006, Contributors <br>
  All rights reserved. <br>
  See ../../../Copyright.txt for details. <br>
*/

#ifndef MemRefExpr_H
#define MemRefExpr_H

#include <iostream>
#include <cassert>
#include <OpenAnalysis/Utils/OA_ptr.hpp>
#include <OpenAnalysis/IRInterface/IRHandles.hpp>
#include <OpenAnalysis/OABase/Annotation.hpp>

namespace OA {

class MemRefExpr;
class IdxExprAccess;
class MemRefExpr;
class NamedRef;
class UnnamedRef;
class UnknownRef;
class RefOp;
class Deref;
class SubSetRef;
class IdxAccess;
class IdxExprAccess;
class FieldAccess;

class MemRefExprVisitor;

// ----- Iterator classes -----
template<class T>
class MREIteratorClass {
  public:
    MREIteratorClass() { }
    virtual ~MREIteratorClass() { }

    // Returns the current item.
    virtual OA_ptr<T> current() const = 0;

    // False when all items are exhausted.;
    virtual bool isValid() const = 0;

    // For Andy
    // PLM 2/27/07 Do we need count ?
    // If yes, then Please do corresponding
    // implementation for Open64MemRefExprIterator
    // virtual int count() const = 0;
        
    virtual void operator++() = 0;
    void operator++(int) { ++*this; } ;

    virtual void reset() = 0;
};

typedef MREIteratorClass<MemRefExpr>    MemRefExprIterator;
typedef MREIteratorClass<NamedRef>      NamedRefIterator;
typedef MREIteratorClass<UnnamedRef>    UnnamedRefIterator;
typedef MREIteratorClass<UnknownRef>    UnknownRefIterator;
typedef MREIteratorClass<RefOp>         RefOpIterator;
typedef MREIteratorClass<Deref>         DerefIterator;
typedef MREIteratorClass<SubSetRef>     SubSetRefIterator;
typedef MREIteratorClass<IdxAccess>     IdxAccessIterator;
typedef MREIteratorClass<IdxExprAccess> IdxExprAccessIterator;
typedef MREIteratorClass<FieldAccess>   FieldAccessIterator;

// ------ MemRefExpr classes -----

/*! abstract base class that has default implementations for the
    methods that all MemRefExpr's must provide
*/
class MemRefExpr : public Annotation {
  public:
    typedef enum {
      USE,     // mem ref specifies where to find source location for use
      DEF,     // mem ref specifies where to put result of assign
      USEDEF,  // mem ref that specifies a location that will be used first
               // and then defined (eg. i++)
      DEFUSE   // mem ref that specifies a location that will be defined first
               // and then used (eg. i++)
    } MemRefType;

    MemRefExpr(MemRefType mrType) : mMemRefType(mrType) {}

    //! copy constructor
    MemRefExpr(MemRefExpr &mre) : mMemRefType(mre.mMemRefType) {}

    virtual ~MemRefExpr() {}

    virtual void acceptVisitor(MemRefExprVisitor& pVisitor) = 0;

    // return a ptr to a copy of self
    virtual OA_ptr<MemRefExpr> clone() = 0;

    //*****************************************************************
    // Subclass type methods 
    //*****************************************************************
    virtual bool isaNamed() { return false; }
    virtual bool isaUnnamed() { return false; }
    virtual bool isaUnknown() { return false; }
    virtual bool isaRefOp() { return false; }
    
    virtual bool isaDeref() { return false; }
    virtual bool isaAddressOf() { return false; }

    virtual bool isaSubSetRef() { return false; }
    virtual bool isaIdxAccess() { return false; }
    virtual bool isaIdxExprAccess() { return false; }
    virtual bool isaFieldAccess() { return false; }

    //*****************************************************************
    // Info methods 
    //*****************************************************************
    
    //! whether USE/DEF MemRefExpr    
    MemRefType getMRType() { return mMemRefType; }

    //! is this a def mem ref
    bool isDef() { return (mMemRefType==DEF 
                           || mMemRefType == USEDEF || mMemRefType == DEFUSE); }

    //! is this a use mem ref
    bool isUse() { return (mMemRefType==USE 
                          || mMemRefType == USEDEF || mMemRefType == DEFUSE); }

    //! is this a defuse mem ref
    bool isDefUse() { return (mMemRefType==DEFUSE); }

    //! is this a usedef mem ref
    bool isUseDef() { return (mMemRefType==USEDEF); }

    //*****************************************************************
    // Construction methods 
    //*****************************************************************

    //! specify the memory reference type
    void setMemRefType(MemRefExpr::MemRefType mrType) { mMemRefType = mrType; }

    //*****************************************************************
    // Relationship methods 
    //*****************************************************************

    //! an ordering for locations, needed for use within STL containers
    virtual bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    virtual bool operator==(MemRefExpr& other);
    
    //! check if two memory references are not equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator!=(MemRefExpr& other) { return ! ((*this)==other); }
    
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    // helper functions for output
    std::string toString(MemRefType);

    //*****************************************************************
    // Debugging methods 
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { assert(0); return sOrder; }

private:
    static const int sOrder = -100;
    MemRefType mMemRefType;
};

/*!
   A named memory reference has a SymHandle base. 
   Examples include references involving local and global variables.
*/
class NamedRef: public MemRefExpr {
  public:

    NamedRef(MemRefType mrType, SymHandle sh)
        : MemRefExpr(mrType), mSymHandle(sh) { }

    //! copy constructor
    NamedRef(NamedRef &mre) : MemRefExpr(mre), mSymHandle(mre.mSymHandle) { }
    
    NamedRef(MemRefExpr &mre, SymHandle sh) : MemRefExpr(mre), mSymHandle(sh) {}

    ~NamedRef() { }

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // Subclass type methods 
    //*****************************************************************
    bool isaNamed() { return true; }
    
    //*****************************************************************
    // Info methods 
    //*****************************************************************
    SymHandle getSymHandle() { return mSymHandle; }
    
    //*****************************************************************
    // Relationship methods 
    //*****************************************************************

    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);

    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods 
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

  private:
    static const int sOrder = 100;
    SymHandle mSymHandle;
};

/*!
   An unnamed memory reference has a StmtHandle base. 
   Examples include references involving dynamically allocated locations.
*/
class UnnamedRef: public MemRefExpr {
  public:

    UnnamedRef(MemRefType mrType, ExprHandle sh)
        : MemRefExpr(mrType), mExprHandle(sh) { }

    //! copy constructor
    UnnamedRef(UnnamedRef &mre) : MemRefExpr(mre), 
                                  mExprHandle(mre.mExprHandle) {}
    UnnamedRef(MemRefExpr &mre, ExprHandle s) : MemRefExpr(mre), mExprHandle(s) {}

    ~UnnamedRef() { }

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // Subclass type methods 
    //*****************************************************************
    bool isaUnnamed() { return true; }
    
    //*****************************************************************
    // Info methods 
    //*****************************************************************
    ExprHandle getExprHandle() { return mExprHandle; }
    
    //*****************************************************************
    // Relationship methods 
    //*****************************************************************

    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);
    
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods 
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

  private:
    static const int sOrder = 200;
    ExprHandle mExprHandle;
};

/*!
   An unknown memory reference has an unknown base.
   Examples include references involving involving arbitrary function
   calls, eg. *hello()
*/
class UnknownRef: public MemRefExpr {
  public:

    UnknownRef(MemRefType mrType)
        : MemRefExpr(mrType) { }

    //! copy constructor
    UnknownRef(UnknownRef &mre) : MemRefExpr(mre) {}

    ~UnknownRef() { }

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // Subclass type methods 
    //*****************************************************************
    bool isaUnknown() { return true; }
    
    //*****************************************************************
    // Relationship methods 
    //*****************************************************************

    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);
    
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods 
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

  private:
    static const int sOrder = 100000000;
};


/*!
   The RefOp implements a decorator pattern for memory references.
   If we decorate a memory reference with a RefOp it represents either
   a dereference or referencing a subset of a location (eg. field access
   or array access).
*/
class RefOp: public MemRefExpr {
  public:

    RefOp( MemRefType mrType, OA_ptr<MemRefExpr> mre)
        : MemRefExpr(mrType), mMRE(mre) { }
 

    //! copy constructor
    RefOp(RefOp & mre) : MemRefExpr(mre), mMRE(mre.mMRE) { }

    virtual ~RefOp() { }
    
    //*****************************************************************
    // MemRefExpr subclass type methods 
    //*****************************************************************
    bool isaRefOp() { return true; }

    //*****************************************************************
    // Info methods 
    //*****************************************************************
    SymHandle getBaseSym();
    OA_ptr<MemRefExpr> getMemRefExpr() { return mMRE; }

    //*****************************************************************
    // Relationship methods, will be defined in subclasses 
    //*****************************************************************

    //*****************************************************************
    // Construction Method
    //*****************************************************************
    
    //! Will make this Refop wrap the given mre and return the result
    virtual OA_ptr<MemRefExpr> composeWith(OA_ptr<MemRefExpr> mre) = 0;
    
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    virtual void output(IRHandlesIRInterface& ir); 


private:
    OA_ptr<MemRefExpr> mMRE;

};


/* AddressOf class: represents if MemRefExpr has AddressTaken*/
class AddressOf: public RefOp { 
  public: 

    AddressOf(MemRefType mrType, OA_ptr<MemRefExpr> mre)
        : RefOp(mrType, mre) { }
  
    //! copy constructor 
    AddressOf(AddressOf & mre) : RefOp(mre) { } 
 
    ~AddressOf() { } 

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // RefOp subclass type methods
    //*****************************************************************
    bool isaAddressOf() { return true; }

    //*****************************************************************
    // Relationship methods
    //*****************************************************************

    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);

    //*****************************************************************
    // Construction Method
    //*****************************************************************
    //! Will make this Refop wrap the given mre and return the result
    OA_ptr<MemRefExpr> composeWith(OA_ptr<MemRefExpr> mre);

    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir);

    //*****************************************************************
    // Debugging methods
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

 private: 
    static const int sOrder = 350; 
}; 


/*!
   The Deref class indicates how many times a memory reference is 
   being dereferenced.
*/
class Deref: public RefOp {
  public:

    Deref(MemRefType mrType, OA_ptr<MemRefExpr> mre,
          int numDeref)
      : RefOp(mrType, mre), mNumDeref(numDeref) { }

    
    // default values
    Deref(MemRefType mrType, OA_ptr<MemRefExpr> mre)
      : RefOp(mrType, mre), mNumDeref(1) { }

    
    //! copy constructor
    Deref(Deref &mre) : RefOp(mre), mNumDeref(mre.mNumDeref) {}

    ~Deref() { }

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // RefOp subclass type methods 
    //*****************************************************************
    bool isaDeref() { return true; }
    
    //*****************************************************************
    // Info methods 
    //*****************************************************************
    int getNumDerefs() { return mNumDeref; }

    //*****************************************************************
    // Relationship methods
    //*****************************************************************
    
    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);
    
    //*****************************************************************
    // Construction Method
    //*****************************************************************
    
    //! Will make this Refop wrap the given mre and return the result
    OA_ptr<MemRefExpr> composeWith(OA_ptr<MemRefExpr> mre);
    
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods 
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

private:
    static const int sOrder = 300;
    int mNumDeref;
};

/*!
   The SubSetRef implements a decorator pattern for memory references.
   If we decorate a memory reference with a subclass
   of SubSetRef it represents some operation such as a field 
   access or array access occuring.
   Many sub set reference operations are possible abstractions are possible.
*/
class SubSetRef: public RefOp {
  public:

    SubSetRef( MemRefType mrType, OA_ptr<MemRefExpr> mre)
      : RefOp(mrType, mre) {} //{ if (!mre.ptrEqual(0)) assert( ! mre->isaSubSetRef() ); }

    //! copy constructor
    SubSetRef(SubSetRef & mre) : RefOp(mre) { }

    virtual ~SubSetRef() { }

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // RefOp subclass type methods 
    //*****************************************************************
    virtual bool isaSubSetRef() { return true; }
    virtual bool isSubClassOfSubSetRef() { return false; }
    
    //*****************************************************************
    // Relationship methods, will be defined in subclasses
    //*****************************************************************
    
    virtual bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    virtual bool operator==(MemRefExpr& other);
    
    //*****************************************************************
    // Construction Method
    //*****************************************************************
    
    //! Will make this Refop wrap the given mre and return the result
    OA_ptr<MemRefExpr> composeWith(OA_ptr<MemRefExpr> mre);
 
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods    
    //****************************************************************    
    virtual void dump(std::ostream& os, 
                       OA_ptr<IRHandlesIRInterface> pIR);  

    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);
    virtual int getOrder() { return sOrder; }          

private:
    static const int sOrder = 600;

};


/*!
   The IdxAccess class indicates a constant array index.
*/
class IdxAccess: public SubSetRef {
  public:

    IdxAccess(MemRefType mrType, OA_ptr<MemRefExpr> mre, int idx)
      : SubSetRef(mrType,mre), mIdx(idx) { }

    //! copy constructor
    IdxAccess(IdxAccess &mre) : SubSetRef(mre), mIdx(mre.mIdx) {}

    ~IdxAccess() { }

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // SubSetRef subclass type methods 
    //*****************************************************************
    bool isaIdxAccess() { return true; }
    bool isSubClassOfSubSetRef() { return true; }
    
    //*****************************************************************
    // Info methods 
    //*****************************************************************
    int getIdx() { return mIdx; }

    //*****************************************************************
    // Relationship methods
    //*****************************************************************
    
    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);
    
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods 
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

private:
    static const int sOrder = 400;
    int mIdx;
};

/*!
   The IdxExprAccess class indicates an array reference with an expression
   being used for an index.

   I'm assuming that all index expressions are affine.
*/
class IdxExprAccess : public SubSetRef {
  public:

    IdxExprAccess( MemRefType mrType, OA_ptr<MemRefExpr> mre,
                   MemRefHandle hExpr)
    : SubSetRef( mrType, mre)
    {
        mhExpr = hExpr;
    }

    //! copy constructor
    IdxExprAccess(IdxExprAccess &mre)
      : SubSetRef(mre),
        mhExpr(mre.mhExpr)
    {
    }

    ~IdxExprAccess() { }

    virtual void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // SubSetRef subclass type methods 
    //*****************************************************************
    bool isaIdxExprAccess() { return true; }
    bool isSubClassOfSubSetRef() { return true; }

    //*****************************************************************
    // Info methods 
    //*****************************************************************
    MemRefHandle getExpr() { return mhExpr; }

    //*****************************************************************
    // Relationship methods
    //*****************************************************************
    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);

    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

  private:
    static const int sOrder = 450;
    MemRefHandle mhExpr;
};

/*!
   The FieldAccess class indicates a field access to an object or struct,
   that is, a.b or a.foo(), not a->b nor b->foo().
*/
class FieldAccess: public SubSetRef {
  public:

    FieldAccess( MemRefType mrType,
            OA_ptr<MemRefExpr> mre, std::string field)
      : SubSetRef(mrType,mre), mFieldName(field) { }

   
    //! copy constructor
    FieldAccess(FieldAccess &mre) : SubSetRef(mre), mFieldName(mre.mFieldName) {}

    ~FieldAccess() { }

    void acceptVisitor(MemRefExprVisitor& pVisitor);

    //! return a ptr to a copy of self
    OA_ptr<MemRefExpr> clone();

    //*****************************************************************
    // SubSetRef subclass type methods 
    //*****************************************************************
    bool isaFieldAccess() { return true; }
    bool isSubClassOfSubSetRef() { return true; }
    
    //*****************************************************************
    // Info methods 
    //*****************************************************************
    std::string getFieldName() { return mFieldName; }

    //*****************************************************************
    // Relationship methods
    //*****************************************************************
    
    bool operator<(MemRefExpr & other);

    //! check if two memory references are equal at the level of
    //! accuracy provided by the MemRefExpr approximation
    bool operator==(MemRefExpr& other);
    
    //*****************************************************************
    // Annotation Interface
    //*****************************************************************
    void output(IRHandlesIRInterface& ir); 

    //*****************************************************************
    // Debugging methods 
    //*****************************************************************
    virtual void dump(std::ostream& os, OA_ptr<IRHandlesIRInterface> pIR);
    virtual void dump(std::ostream& os, IRHandlesIRInterface& pIR);
    virtual void dump(std::ostream& os);

    virtual int getOrder() { return sOrder; }

private:
    static const int sOrder = 500;
    std::string mFieldName;
};


} // end of OA namespace

#endif

