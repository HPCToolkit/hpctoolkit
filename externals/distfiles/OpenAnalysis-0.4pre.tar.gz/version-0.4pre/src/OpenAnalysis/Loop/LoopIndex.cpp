#include "LoopIndex.hpp"

namespace OA {

LoopIndex::LoopIndex(
    OA_ptr<NamedLoc> variable,
    int initialBound,
    int terminalBound,
    int step)
{
    mVariable = variable;
    mInitialBound = initialBound;
    mTerminalBound = terminalBound;
    mStep = step;
}
    
// - [accessor methods] -
OA_ptr<NamedLoc> LoopIndex::getVariable() {
    return mVariable;
}

int LoopIndex::getInitialBound() {
    return mInitialBound;
}

int LoopIndex::getTerminalBound() {
    return mTerminalBound;
}

int LoopIndex::getStep() {
    return mStep;
}

} // end namespaces

