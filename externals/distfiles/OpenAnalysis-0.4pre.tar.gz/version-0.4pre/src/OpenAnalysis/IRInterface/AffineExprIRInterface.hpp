#ifndef AffineExprIRInterface_H
#define AffineExprIRInterface_H

#include <OpenAnalysis/MemRefExpr/MemRefExpr.hpp>
#include <OpenAnalysis/Location/Location.hpp>

namespace OA {
namespace AffineExpr {

enum OpType {
    OP_ADD = 0,
    OP_SUBTRACT,
    OP_MULTIPLY,
    OP_DIVIDE,
    OP_MODULO
};

class AffineExprIRInterface :
    public virtual IRHandlesIRInterface
{
  public:
    AffineExprIRInterface() {}
    virtual ~AffineExprIRInterface() {}

    virtual OA_ptr<Location::Location>
        getLocation(ProcHandle p, SymHandle s) = 0;
    virtual ProcHandle getProcHandle(SymHandle sym) = 0;
    virtual int constValIntVal(ConstValHandle h) = 0;
    virtual OpType getOpType(OpHandle h) = 0;
    virtual OA_ptr<ExprTree> getExprTree(ExprHandle h) = 0;
    virtual OA_ptr<MemRefExprIterator>
        getMemRefExprIterator(MemRefHandle h) = 0;
    virtual MemRefHandle getSymMemRefHandle(SymHandle h) = 0;


    // needed for GCD:
    // !!! seperate into LoopDetection package
    // !!! Create interface for results.
    // bool isInLoop(StmtHanlde h, CFG cfg);
};

} } // end namespaces

#endif
