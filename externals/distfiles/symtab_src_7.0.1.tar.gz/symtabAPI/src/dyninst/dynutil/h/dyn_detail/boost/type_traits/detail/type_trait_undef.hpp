
// NO INCLUDE GUARDS, THE HEADER IS INTENDED FOR MULTIPLE INCLUSION

// Copyright Aleksey Gurtovoy 2002-2004
//
// Distributed under the Boost Software License, Version 1.0. 
// (See accompanying file LICENSE_1_0.txt or copy at 
// http://www.boost.org/LICENSE_1_0.txt)

// $Source$
// $Date: 2004-09-02 11:41:37 -0400 (Thu, 02 Sep 2004) $
// $Revision: 24874 $

#undef DYN_DETAIL_BOOST_TT_AUX_TYPE_TRAIT_DEF1
#undef DYN_DETAIL_BOOST_TT_AUX_TYPE_TRAIT_SPEC1
#undef DYN_DETAIL_BOOST_TT_AUX_TYPE_TRAIT_IMPL_SPEC1
#undef DYN_DETAIL_BOOST_TT_AUX_TYPE_TRAIT_PARTIAL_SPEC1_1
#undef DYN_DETAIL_BOOST_TT_AUX_TYPE_TRAIT_PARTIAL_SPEC1_2
#undef DYN_DETAIL_BOOST_TT_AUX_TYPE_TRAIT_IMPL_PARTIAL_SPEC1_1
