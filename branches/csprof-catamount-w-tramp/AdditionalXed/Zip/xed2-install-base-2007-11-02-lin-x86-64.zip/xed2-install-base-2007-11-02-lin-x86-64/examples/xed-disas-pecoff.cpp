/*BEGIN_LEGAL 
Copyright (c) 2007, Intel Corp.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are
met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.

    * Redistributions in binary form must reproduce the above
      copyright notice, this list of conditions and the following
      disclaimer in the documentation and/or other materials provided
      with the distribution.

    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
END_LEGAL */
/// @file xed-disas-pecoff.cpp
/// @author Mark Charney   <mark.charney@intel.com>

//// ONLY COMPILES IF -mno-cygwin is thrown on to GCC compilations

#include "xed-disas-pecoff.H"

#if defined(XED_PECOFF_FILE_READER)
#include <sstream>
#include <iostream>
#include <iomanip>


// windows specific headers
#include <windows.h>
#include <winnt.h>

// xed headers -- THESE MUST BE AFTER THE WINDOWS HEADERS


extern "C" {
#include "xed-interface.h"
#include "xed-examples-util.h"
#include "xed-portability.h" // This really must be after the windows.h include
}

#include "xed-disas-pecoff.h"
#include "xed-examples-ostreams.h"
using namespace std;

// Pronto
static std::string
windows_error(const char* syscall, 
              const char* filename)
{
    std::ostringstream os;
    os << "Mapped file:: " << syscall
       << " for file " << filename << " failed: ";
    switch (GetLastError())
    {
      case 2:
        os << "File not found";
        break;
      case 3:
	os << "Path not found";
	break;
      case 5:
	os <<  "Access denied";
	break;
      case 15:
	os << "Invalid drive";
	break;
      default:
        os << "error code " << STATIC_CAST(uint32_t,GetLastError());
	break;
    }

    return os.str();
}

class pecoff_reader_t
{
    /// NT handle for the open file.
    void* file_handle_;

    /// NT handle for the memory mapping.
    void* map_handle_;

    void* base_;
    bool okay_;

  public:
    pecoff_reader_t()
    {
        init();
    }
    ~pecoff_reader_t()
    {
        close();
    }

    void* base() const { return base_; }
    bool okay() const { return okay_; }

    void
    init()
    {
        file_handle_ = INVALID_HANDLE_VALUE;
        map_handle_ = INVALID_HANDLE_VALUE;
        okay_ = false;
    }

    void
    close()
    {
        if (base_)
        {
            UnmapViewOfFile(base_);
        }
        if (map_handle_ != INVALID_HANDLE_VALUE)
        {
            CloseHandle(map_handle_);
        }
        if (file_handle_ != INVALID_HANDLE_VALUE)
        {
            CloseHandle(file_handle_);
        }
        
        init();
    }


    bool
    map_region(const char* input_file_name, 
               void*& vregion,
               uint32_t& len)
    {
        std::string error_msg;
        okay_ = false;

        file_handle_ = CreateFile(input_file_name,
                                  GENERIC_READ,
                                  FILE_SHARE_READ,
                                  NULL,
                                  OPEN_EXISTING,
                                  FILE_FLAG_NO_BUFFERING + FILE_ATTRIBUTE_READONLY,
                                  NULL);
        if (file_handle_ == INVALID_HANDLE_VALUE)
        {
            error_msg = windows_error("CreateFile", input_file_name);
            xedex_derror(error_msg.c_str());
        }

        map_handle_ = CreateFileMapping(file_handle_,
                                        NULL,
                                        PAGE_READONLY,
                                        0,
                                        0,
                                        NULL);

        if (map_handle_ == INVALID_HANDLE_VALUE)
        {
            error_msg = windows_error("CreateFileMapping", input_file_name);
            xedex_derror(error_msg.c_str());
        }

        base_ = MapViewOfFile(map_handle_,
                              FILE_MAP_READ, 0, 0, 0);
        if (base_ != NULL)
        {
            okay_ = true;
            vregion = base_;
            len = 0; //FIXME
            return true;
        }
        error_msg = windows_error("MapViewOfFile", input_file_name);
        CloseHandle(map_handle_);
        map_handle_ = INVALID_HANDLE_VALUE;
        
        CloseHandle(file_handle_);
        file_handle_ = INVALID_HANDLE_VALUE;
        return false;
    }

    bool
    module_section_info(const char* secname,
                        uint8_t*& section_start,
                        uint32_t& section_size,
                        uint64_t& virtual_addr)
    {
        // Try to parse the file header.
        const IMAGE_SECTION_HEADER* hdr;
        unsigned int nsections;
        uint64_t image_base;
        unsigned int i,ii;
        if (! parse_nt_file_header(&nsections, &image_base, &hdr))
        {
            xedex_derror("Could not read nt file header");
            return false;
        }
        
        // Extract the name into a 0-padded 8 byte string.
        char my_name[IMAGE_SIZEOF_SHORT_NAME];
        memset(my_name,0,IMAGE_SIZEOF_SHORT_NAME);
        for( i=0;i<IMAGE_SIZEOF_SHORT_NAME;i++)
        {
            my_name[i] = secname[i];
            if (secname[i] == 0)
            {
                break;
            }
        }
        //strncpy(my_name, secname, IMAGE_SIZEOF_SHORT_NAME);
        
        // Search the sections for the correct name.
        for ( ii = 0; ii < nsections; ii++, hdr++)
        {
            if (0 == strncmp((const char*)hdr->Name,
                             my_name,
                             IMAGE_SIZEOF_SHORT_NAME))
            {
                // Found it.  Extract the info and return.
                //ms->module_load_address_ = image_base; //FIXME???
                virtual_addr  = hdr->VirtualAddress;
                section_size = (hdr->Misc.VirtualSize > 0
                             ? hdr->Misc.VirtualSize
                             : hdr->SizeOfRawData);
                section_start = (uint8_t*)ptr_add(base_, hdr->PointerToRawData);
                return true;
            }
        }

        return false;
    }

  private:
    static inline const void*
    ptr_add(const void* ptr, unsigned int n)
    {
        return (const void*)(n + (const char*)ptr);
    }

    // Lifted from Pronto
    bool
    is_valid_module()
    {
        // Point to the DOS header and check it.
        const IMAGE_DOS_HEADER* dh = (const IMAGE_DOS_HEADER*)base_;
        if (dh->e_magic != IMAGE_DOS_SIGNATURE)
        {
            return false;
        }
        
        // Point to the PE signature word and check it.
        const DWORD* sig = (const DWORD*)ptr_add(base_, dh->e_lfanew);
        
        // This must be a valid PE file with a valid DOS header.
        if (*sig != IMAGE_NT_SIGNATURE)
        {
            return false;
        }
        return true;
    }


    bool
    parse_nt_file_header(unsigned int* pnsections,
                         uint64_t* pimage_base,
                         const IMAGE_SECTION_HEADER** phdr)
    {
        // Oh joy - the format of a .obj file on Windows is *different*
        // from the format of a .exe file.  Deal with that.
        const IMAGE_FILE_HEADER* ifh;
        
        // Check the header to see if this is a valid .exe file
        if (is_valid_module())
        {
            // Point to the DOS header.
            const IMAGE_DOS_HEADER* dh = (const IMAGE_DOS_HEADER*)base_;
            
            // Point to the COFF File Header (just after the signature)
            ifh = (const IMAGE_FILE_HEADER*)ptr_add(base_, dh->e_lfanew + 4);
        }
        else
        {
            // Maybe this is a .obj file, which starts with the image file header
            ifh = (const IMAGE_FILE_HEADER*)base_;
        }
        
#if !defined(IMAGE_FILE_MACHINE_IA64)
# define IMAGE_FILE_MACHINE_IA64 0x0200
#endif
#if !defined(IMAGE_FILE_MACHINE_AMD64)
# define IMAGE_FILE_MACHINE_AMD64 0x8664
#endif

        if (ifh->Machine != IMAGE_FILE_MACHINE_I386
            && ifh->Machine != IMAGE_FILE_MACHINE_AMD64)
        {
            // We only support Windows formats on IA32 and Intel64
            return false;
        }
        
        if (ifh->Machine == IMAGE_FILE_MACHINE_AMD64)
        {
            cout << "Intel64 format" << endl;
        }
        if (ifh->Machine == IMAGE_FILE_MACHINE_I386)
        {
            cout << "IA32 format" << endl;
        }
        
        // Well, we probably have a pointer to the image file header now.
        *pimage_base = 0;
        
        // The optional header can be either 32-bit or 64-bit oriented.
        // In either case, extract the preferred link base of the image.
        const IMAGE_OPTIONAL_HEADER* opthdr;

// Cygwin's w32api winnt.h header doesn't distinguish 32 and 64b.
#if !defined(IMAGE_NT_OPTIONAL_HDR32_MAGIC)
# define IMAGE_NT_OPTIONAL_HDR32_MAGIC IMAGE_NT_OPTIONAL_HDR_MAGIC
#endif
// And it lacks the definition for 64b headers
#if !defined(IMAGE_NT_OPTIONAL_HDR64_MAGIC)
# define IMAGE_NT_OPTIONAL_HDR64_MAGIC 0x20b
#endif
        opthdr = (const IMAGE_OPTIONAL_HEADER*)ptr_add(ifh, sizeof(*ifh));
        if (ifh->SizeOfOptionalHeader > 0)
        {
            if (opthdr->Magic == IMAGE_NT_OPTIONAL_HDR32_MAGIC)
            {
                *pimage_base = opthdr->ImageBase;
            }
            else if (opthdr->Magic == IMAGE_NT_OPTIONAL_HDR64_MAGIC)
            {
#if defined(_MSC_VER)
# if _MSC_VER >= 1400
                const IMAGE_OPTIONAL_HEADER64* opthdr64;
                opthdr64 = (const IMAGE_OPTIONAL_HEADER64*)opthdr;
                *pimage_base = opthdr64->ImageBase;
# else
                xedex_derror("No support for 64b optional headers because older MS compilers do not have the type yet");
# endif
#else
                xedex_derror("No support for 64b optional headers because cygwin does nt have the type yet");
                return false;
#endif
            }
            else 
            {
                // Optional header is not a form we recognize, so punt.
                return false;
            }
        }
        
        // Point to the first of the Section Headers
        *phdr = (const IMAGE_SECTION_HEADER*)ptr_add(opthdr,
                                                     ifh->SizeOfOptionalHeader);
        *pnsections = ifh->NumberOfSections;
        return true;
    }



};

////////////////////////////////////////////////////////////////////////////

void
process_pecoff64(uint8_t* start,
                 unsigned int length,
                 xed_decode_file_info_t& decode_info,
                 pecoff_reader_t& reader)
{
    //xedex_derror("process_pecoff64 not done yet");

    uint8_t* section_start = 0;
    uint32_t section_size = 0;
    uint64_t runtime_vaddr  = 0;
    
    bool okay = reader.module_section_info(".text",
                                           section_start,
                                           section_size,
                                           runtime_vaddr);

    if (!okay)
    {
        xedex_derror("text section not found");
    }

    xed_disas_test(&decode_info.dstate, 
                   REINTERPRET_CAST(unsigned char*,start),
                   REINTERPRET_CAST(unsigned char*,section_start), 
                   REINTERPRET_CAST(unsigned char*,section_start + section_size),
               decode_info.ninst,
               runtime_vaddr,
               decode_info.decode_only);
    (void) length;
}



void
process_pecoff32(uint8_t* start,
                unsigned int length,
                 xed_decode_file_info_t& decode_info,
                 pecoff_reader_t& reader)
{
    uint8_t* section_start = 0;
    uint32_t section_size = 0;
    uint64_t runtime_vaddr  = 0;
    
    bool okay = reader.module_section_info(".text",
                                           section_start,
                                           section_size,
                                           runtime_vaddr);

    if (!okay)
    {
        xedex_derror("text section not found");
    }

    xed_disas_test(&decode_info.dstate, 
                   REINTERPRET_CAST(unsigned char*,start),
                   REINTERPRET_CAST(unsigned char*,section_start), 
                   REINTERPRET_CAST(unsigned char*,section_start + section_size),
               decode_info.ninst,
               runtime_vaddr,
               decode_info.decode_only);

    (void) length;
}

void
xed_disas_pecoff(const char* input_file_name,
                 const xed_state_t* dstate,
                 int ninst,
                 bool sixty_four_bit,
                 bool decode_only)
{
    uint8_t* region = 0;
    void* vregion = 0;
    uint32_t len = 0;
    pecoff_reader_t image_reader;
    bool okay = image_reader.map_region(input_file_name, vregion, len);
    if (!okay)
        xedex_derror("image read failed");
    if (CLIENT_VERBOSE1)
        printf("Mapped image\n");
    region = REINTERPRET_CAST(uint8_t*,vregion);
    
    xed_decode_file_info_t decode_info;
    xed_decode_file_info_init(&decode_info, dstate, ninst, decode_only);    

    if (sixty_four_bit) 
        process_pecoff64(region, len,  decode_info, image_reader);
    else 
        process_pecoff32(region, len,  decode_info, image_reader);
    xed_print_decode_stats();
}
 


#endif
//Local Variables:
//pref: "xed-disas-pecoff.H"
//End:
