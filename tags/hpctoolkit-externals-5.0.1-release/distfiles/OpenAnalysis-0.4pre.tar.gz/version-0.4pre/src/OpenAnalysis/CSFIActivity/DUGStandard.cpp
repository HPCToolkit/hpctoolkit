/*! \file
  
  \brief Implementation of DUGStandard.

  \authors Michelle Strout
  \version $Id: DUGStandard.cpp,v 1.3 2005/10/17 21:21:41 garvin Exp $

  Copyright (c) 2002-2004, Rice University <br>
  Copyright (c) 2004, University of Chicago <br>  
  All rights reserved. <br>
  See ../../../Copyright.txt for details. <br>
*/

//--------------------------------------------------------------------
//--------------------------------------------------------------------

// #define DEBUG_DUAA_LAST
// standard headers

#include <string.h>
#include <stdlib.h>
#include <iostream>
using std::ostream;
using std::endl;
using std::cout;
using std::cerr;

#include "DUGStandard.hpp"

namespace OA {
  namespace DUG {

//--------------------------------------------------------------------

//--------------------------------------------------------------------
// must be updated any time DUG::Interface::EdgeType changes
static const char *sEdgeTypeToString[] = { 
  "F",
  "C",
  "R",
  "P"
//   "CFLOW",
//   "CALL",
//   "RETURN",
//   "PARAM"
};
// must be updated any time DUG::Interface::EdgeType changes
// static const char *sNodeTypeToString[] = { 
//   "CFLOW_NODE",
//   "CALL_NODE",
//   "RETURN_NODE",
//   "ENTRY_NODE",
//   "EXIT_NODE"
// };
static const char *sNodeTypeToString[] = { 
  "FORMALPARAM_NODE",
  "NONEFORMAL_NODE",
};

//--------------------------------------------------------------------
/*! called by all Node constructors
 */
void Node::Ctor() { 

    mDGNode = new DGraph::NodeImplement;

    mVaried = false;
    mUseful = false;
    mSelfDependent = false;
}


OA_ptr<EdgeInterface> EdgesIterator::currentDUGEdge() const
      {
         return current().convert<Edge>();
      }



   OA_ptr<NodeInterface> NodesIterator::currentDUGNode() const
      {
           return current().convert<Node>();
      }




//--------------------------------------------------------------------
void
Node::dump (ostream& os, OA_ptr<IRHandlesIRInterface> ir)
{
  os << sNodeTypeToString[mType] << std::endl;
}

bool Node::operator==(DGraph::NodeInterface& other) 
{
    
    return mDGNode->operator==(other);
}

bool Node::operator<(DGraph::NodeInterface& other) 
{
    return mDGNode->operator<(other);
}



void
Node::longdump (ostream& os, OA_ptr<IRHandlesIRInterface> ir)
{
  // print the node ID
  os << "DUGStandard Node: ";
  dump(os,ir);
  
  if (isAnEntry()) {
    os << " (ENTRY)";
  } else if (isAnExit()) {
    os << " (EXIT)"; 
  }
  os << endl;
  
  // print the source(s)
  unsigned int count = 0;
  OA_ptr<NodesIteratorInterface> srcIter = getDUGSourceNodesIterator();
  for ( ; srcIter->isValid(); ++(*srcIter), ++count) {
    OA_ptr<NodeInterface> node = srcIter->currentDUGNode();
    if (count == 0) { os << " <-- ("; }
    else            { os << ", "; }

    node->dump(os,ir);
  }
  if (count > 0) { os << ")" << endl; }
  
  // print the sink(s)
  count = 0;
  OA_ptr<NodesIteratorInterface> outIter = getDUGSinkNodesIterator();
  for ( ; outIter->isValid(); ++(*outIter), ++count) {
    OA_ptr<NodeInterface> node = outIter->currentDUGNode();
    if (count == 0) { os << " --> ("; } 
    else            { os << ", "; }
    
    node->dump(os,ir);
  }
  if (count > 0) { os << ")" << endl; }
}

void
Node::dumpdot (ostream& os, OA_ptr<IRHandlesIRInterface> ir)
{
    
  // print the node
  os << getId() << " [ label=\"==  DUG ";
  os << sNodeTypeToString[getType()] << " " << getId() << " ==";
  
  if (isAnEntry()) {
    os << " (entry)";
  } 
  else if (isAnExit()) {
    os << " (exit)"; 
  }
  os << "\\n"; 


  os << "\" ];" << endl;
  os.flush();
    
}

//--------------------------------------------------------------------

OA_ptr<DGraph::EdgesIteratorInterface> 
    Node::getIncomingEdgesIterator() const
{
    return mDGNode->getIncomingEdgesIterator();
}

OA_ptr<DGraph::EdgesIteratorInterface> 
    Node::getOutgoingEdgesIterator() const
{
    return mDGNode->getOutgoingEdgesIterator();
}

OA_ptr<DGraph::NodesIteratorInterface> 
    Node::getSourceNodesIterator() const
{
    return mDGNode->getSourceNodesIterator();
}

OA_ptr<DGraph::NodesIteratorInterface> 
    Node::getSinkNodesIterator() const
{
    return mDGNode->getSourceNodesIterator();
}

OA_ptr<EdgesIteratorInterface>
    Node::getDUGIncomingEdgesIterator() const
{
   OA_ptr<EdgesIterator> retval;
   retval = new EdgesIterator(getIncomingEdgesIterator());
   return retval;

}

OA_ptr<EdgesIteratorInterface>
    Node::getDUGOutgoingEdgesIterator() const
{
   OA_ptr<EdgesIterator> retval;
   retval = new EdgesIterator(getOutgoingEdgesIterator());
   return retval;

}

OA_ptr<NodesIteratorInterface>
    Node::getDUGSourceNodesIterator() const
{
   OA_ptr<NodesIterator> retval;
   retval = new NodesIterator(getSourceNodesIterator());
   return retval;

}

OA_ptr<NodesIteratorInterface>
    Node::getDUGSinkNodesIterator() const
{
   OA_ptr<NodesIterator> retval;
   retval = new NodesIterator(getSinkNodesIterator());
   return retval;

}



//--------------------------------------------------------------------
//--------------------------------------------------------------------
Edge::Edge (OA_ptr<DUGStandard> pDUG,
                          OA_ptr<Node> pNode1, 
                          OA_ptr<Node> pNode2, 
                          EdgeType pType, CallHandle call,
                         ProcHandle proc)
  : mDUG(pDUG), mNode1(pNode1), mNode2(pNode2), mType(pType), 
    mCall(call), mProc(proc)
{

  // create DGraphEdge for associated DGraph
  mDGEdge = new DGraph::EdgeImplement(pNode1->mDGNode,
                                             pNode2->mDGNode);

}

// DUGStandard::Edge::Edge (OA_ptr<DUGStandard> pDUG,
//                           OA_ptr<Node> pNode1, 
//                           OA_ptr<Node> pNode2, 
//                           EdgeType pType)
//   : mDUG(pDUG), mNode1(pNode1), mNode2(pNode2), mType(pType), 
//     mCall(ExprHandle(0)), mProc(ProcHandle(0))
// {
//   mId = sNextId++;

//   // create DGraphEdge for associated DGraph
//   mDGEdge = new DGraph::DGraphStandard::Edge(pNode1->mDGNode,
//                                              pNode2->mDGNode);

// }


//--------------------------------------------------------------------
bool Edge::operator==(DGraph::EdgeInterface& other) 
{
    
    return mDGEdge->operator==(other);
}

bool Edge::operator<(DGraph::EdgeInterface& other) 
{
    return mDGEdge->operator<(other);
}



void Edge::dump(ostream& os)
{
  os << sEdgeTypeToString[mType];
}

void Edge::dumpdot(ostream& os)
{
    os << getSource()->getId() << " -> " << getSink()->getId(); 
    switch(mType) {
        case (CALL_EDGE):
            os << " [label=\"CALL_EDGE\", style=dashed];" << std::endl;
            break;
        case (RETURN_EDGE):
            os << " [label=\"RETURN_EDGE\", style=dashed];" << std::endl;
            break;
        case (CFLOW_EDGE):
            os << ";" << std::endl;
            break;
    }

    os.flush();
}


//--------------------------------------------------------------------
//--------------------------------------------------------------------
DUGStandard::DUGStandard(
                         OA_ptr<DUGIRInterface> pIR,
                         OA_ptr<DataFlow::ParamBindings> pParamBind,
                         OA_ptr<OA::Alias::InterAliasMap> interAlias) 
    : mIR(pIR), mParamBind(pParamBind), mAlias(interAlias)
{
  mEntry       = mExit = NULL;
  mDGraph      = new DGraph::DGraphImplement;
  mCallNodes   = new std::list<OA_ptr<Node> >;
  mReturnNodes = new std::list<OA_ptr<Node> >;
  mActiveSymSet    = new std::set<SymHandle>;
  mActiveMemRefSet = new std::set<MemRefHandle>;
  mActiveStmtSet   = new std::set<StmtHandle>;
  mUnknownLocActive = false;
}


DUGStandard::~DUGStandard()
{
  mEntry = NULL;
  mExit = NULL;
}

//--------------------------------------------------------------------
// DUGStandard Methods
//--------------------------------------------------------------------

OA_ptr<Edge> 
DUGStandard::getDUGEdge(
        const OA_ptr<DGraph::EdgeInterface> dgEdge) const
{

    
  assert (0); 
  OA_ptr<Edge> retval;
  /*! commented out by PLM 09/20/06
  DGEdgeToEdgeMap::const_iterator pos;
  pos = mDGEdgeToDUGEdge.find(dgEdge);
  if (pos != mDGEdgeToDUGEdge.end()) {
      retval =  pos->second;
  } else {
      assert(0); // querying about DGG edge that doesn't have a
                 // corresponding DUG edge, Manager should make
                 // sure this doesn't happen
  }
  */
  return retval;
}

OA_ptr<Node> 
DUGStandard::getDUGNode(
        const OA_ptr<DGraph::NodeInterface> dgNode) const
{
  assert(0);   
  OA_ptr<Node> retval;
  /*! commented out by PLM 09/20/06
  DGNodeToNodeMap::const_iterator pos;
  pos = mDGNodeToDUGNode.find(dgNode);
  if (pos != mDGNodeToDUGNode.end()) {
      retval =  pos->second;
  } else {
      assert(0); // querying about DG node that doesn't have a
                 // corresponding DUG node, Manager should make
                 // sure this doesn't happen
  }
  */
  return retval; 
}

void DUGStandard::addEdge(OA_ptr<DGraph::EdgeInterface> pEdge)
{
    mDGraph->addEdge(pEdge);
}

void DUGStandard::addNode(OA_ptr<DGraph::NodeInterface> pNode)
{
    
    mDGraph->addNode(pNode);
}


/*! commented out by PLM 09/21/06
void DUGStandard::addEdge(OA_ptr<Edge> pEdge)
{
  assert(!pEdge.ptrEqual(0));

  // associate the DGEdge with given DUG edge
  //mDGEdgeToDUGEdge[pEdge->mDGEdge] = pEdge;

  // add associated DGraph edge to underlying DGraph
  
  OA_ptr<DGraph::NodeInterface> dEdge = pEdge.convert<DGraph::EdgeInterface>();
   
  mDGraph->addEdge(dEdge);

  // add to complete list of edges
  mEdges->push_back(pEdge);
}


void DUGStandard::addNode(OA_ptr<Node> pNode)
{
    assert(!pNode.ptrEqual(0));
    if ( pNode->mDGNode.ptrEqual(0) ) {
        assert(0);
    } else {
    //    mDGNodeToDUGNode[pNode->mDGNode] = pNode;
    }
    
    
    OA_ptr<DGraph::NodeInterface> dNode = pNode.convert<DGraph::NodeInterface>();
    mDGraph->addNode(dNode);
    
    // add to complete list of edges
    mNodes->push_back(pNode);

}
*/

OA_ptr<DGraph::NodesIteratorInterface> DUGStandard::getNodesIterator() const
{
    return mDGraph->getNodesIterator();
}

OA_ptr<DGraph::NodesIteratorInterface>
DUGStandard::getEntryNodesIterator( ) const
{
    
    return mDGraph->getEntryNodesIterator();
}

OA_ptr<DGraph::NodesIteratorInterface>
DUGStandard::getExitNodesIterator( ) const
{
    return mDGraph->getExitNodesIterator();
}


OA_ptr<DGraph::EdgesIteratorInterface> DUGStandard::getEdgesIterator() const
{
    
    return mDGraph->getEdgesIterator();
}

OA_ptr<DGraph::NodesIteratorInterface> DUGStandard::getDFSIterator(OA_ptr<DGraph::NodeInterface> n) 
{
    
    
    return mDGraph->getDFSIterator(n);
}

OA_ptr<DGraph::NodesIteratorInterface> DUGStandard::getBFSIterator() 
{ 
    assert(0); 
    OA_ptr<DGraph::NodesIteratorInterface> retval; 
    return retval;
}


OA_ptr<DGraph::NodesIteratorInterface>
DUGStandard::getReversePostDFSIterator( DGraph::DGraphEdgeDirection pOrient)
{
    return mDGraph->getReversePostDFSIterator(pOrient);
}

OA_ptr<DGraph::NodesIteratorInterface>
DUGStandard::getReversePostDFSIterator(OA_ptr<DGraph::NodeInterface> root, 
                                        DGraph::DGraphEdgeDirection pOrient)
{
    assert(0);
    OA_ptr<DGraph::NodesIteratorInterface> retval;
    /*
    OA_ptr<std::list<OA_ptr<DGraph::Interface::Node> > > dgList
        = DGraph::create_reverse_post_order_list(*mDGraph, root, pOrient);
    OA_ptr<std::list<OA_ptr<DUGStandard::Node> > > retlist 
        = convert_to_DUG(dgList);
    retval = new NodesIterator(retlist);
    */
    return retval;
}

/*! FIXME: for now just returning a ReversePostDFSIterator that
    starts at exit.  For data-flow analysis this is actually better
    but DGraphDFProblem has to get the PostDFSIterator because
    not all graphs (eg. callgraph) have an exit node.
*/
OA_ptr<DGraph::NodesIteratorInterface> 
DUGStandard::getPostDFSIterator(DGraph::DGraphEdgeDirection pOrient)
{
    assert(0);
    OA_ptr<DGraph::NodesIteratorInterface> retval; 
    /*
    if (pOrient == DGraph::DEdgeOrg) {
        return getReversePostDFSIterator(DGraph::DEdgeRev);
    } else {
        return getReversePostDFSIterator(DGraph::DEdgeOrg);
    }
    */
    return retval; 
}

OA_ptr<DGraph::NodesIteratorInterface>
DUGStandard::getPostDFSIterator(OA_ptr<DGraph::NodeInterface> root, 
                                 DGraph::DGraphEdgeDirection pOrient)
{
    assert(0);
    OA_ptr<DGraph::NodesIteratorInterface> retval;
    return retval;
}


OA_ptr<NodesIteratorInterface> DUGStandard::getDUGNodesIterator() const
{
   OA_ptr<NodesIterator> retval;
   retval = new NodesIterator(getNodesIterator());
   return retval;

}


OA_ptr<NodesIteratorInterface>
DUGStandard::getDUGEntryNodesIterator( ) const
{
 OA_ptr<NodesIterator> retval;
   retval = new NodesIterator(getEntryNodesIterator());
   return retval;


}

OA_ptr<NodesIteratorInterface>
DUGStandard::getDUGExitNodesIterator( ) const
{
 OA_ptr<NodesIterator> retval;
   retval = new NodesIterator(getExitNodesIterator());
   return retval;


}

OA_ptr<EdgesIteratorInterface> DUGStandard::getDUGEdgesIterator() const
{
 OA_ptr<EdgesIterator> retval;
   retval = new EdgesIterator(getEdgesIterator());
   return retval;


}


OA_ptr<NodesIteratorInterface>
DUGStandard::getDUGReversePostDFSIterator( DGraph::DGraphEdgeDirection pOrient)
{
 OA_ptr<NodesIterator> retval;
   retval = new NodesIterator(getReversePostDFSIterator(pOrient));
   return retval;


}




OA_ptr<NodesIteratorInterface>
      DUGStandard::getDUGDFSIterator(OA_ptr<NodeInterface> n)
{
 OA_ptr<NodesIterator> retval;
   retval = new NodesIterator(getDFSIterator(n));
   return retval;


}



/*! converts more general list to list of subclass type
    needed so the helper functions that generate orderings operate
    on the more general DGraph::Interface
 */
/*! commented out by PLM 09/20/06
OA_ptr<std::list<OA_ptr<Node> > > 
DUGStandard::convert_to_DUG(
        OA_ptr<std::list<OA_ptr<DGraph::Interface::Node> > > pList) const
{
    OA_ptr<std::list<OA_ptr<DUGStandard::Node> > > retval;
    retval = new std::list<OA_ptr<DUGStandard::Node> >;

    std::list<OA_ptr<DGraph::Interface::Node> >::iterator nodeIter;
    for (nodeIter=pList->begin(); nodeIter!=pList->end(); nodeIter++ ) {
        OA_ptr<DGraph::Interface::Node> dgNode = *nodeIter;
        //retval->push_back(dgNode.convert<DUGStandard::Node>());
        OA_ptr<DGraph::DGraphStandard::Node> dgStdNode 
            = dgNode.convert<DGraph::DGraphStandard::Node>();
        DGNodeToNodeMap::const_iterator pos = mDGNodeToDUGNode.find(dgStdNode);
        if (pos != mDGNodeToDUGNode.end()) {
            retval->push_back(pos->second);
        }
    }

    return retval;
}
*/

/*
OA_ptr<std::list<OA_ptr<DGraph::Interface::Node> > > 
DUGStandard::create_reverse_post_order_list(DGraph::Interface& pDGraph,
                                     OA_ptr<DGraph::Interface::Node> root,
                                     DGraph::DGraphEdgeDirection pOrient)
{
    // loop over all nodes and set their visit field to false
    OA_ptr<DGraph::Interface::NodesIterator> nodeIter
        = pDGraph.getNodesIterator();
    for ( ; nodeIter->isValid(); (*nodeIter)++ ) {
        OA_ptr<DGraph::Interface::Node> node = nodeIter->current();
        node->clearVisitFlag();
    }

    // generate a list of nodes in the requested ordering
    OA_ptr<std::list<OA_ptr<DGraph::Interface::Node> > > retval;
    retval = new std::list<OA_ptr<DGraph::Interface::Node> >;
    
    reverse_postorder_recurse(pDGraph, root, pOrient, retval);

    return retval;

}

void DUGStandard::reverse_postorder_recurse(DGraph::Interface& pDGraph, 
                 OA_ptr<DGraph::Interface::Node> pNode,
                 DGraph::DGraphEdgeDirection pOrient,
                 OA_ptr<std::list<OA_ptr<DGraph::Interface::Node> > > pList )
{
    OA_ptr<DGraph::Interface::NodesIterator> neighIter;
    
    // mark as visited so that we don't get in an infinite
    // loop on cycles in the graph
    pNode->setVisitFlag();

    // loop over the successors or predecessors based on orientation
    if (pOrient==DGraph::DEdgeOrg) {
      neighIter =  pNode->getSinkNodesIterator();
    } else {
      neighIter = pNode->getSourceNodesIterator();
    }
    for (; neighIter->isValid(); ++(*neighIter)) {
        OA_ptr<DGraph::Interface::Node> n; 
        n = neighIter->current();

        // if the node hasn't been visited then call recursively 
        if (!n->getVisitFlag()) {
            reverse_postorder_recurse(pDGraph, n, pOrient, pList);
        }
    }

    // add ourselves to the beginning of the list
    pList->push_front(pNode);
}
*/


void
DUGStandard::dump (ostream& os, OA_ptr<IRHandlesIRInterface> ir)
{
  os << "===== DUGStandard: =====\n"
     << endl;
  
  // print the contents of all the nodes
  OA_ptr<NodesIteratorInterface> nodeIter = getDUGNodesIterator();
  for ( ; nodeIter->isValid(); ++(*nodeIter)) {
    OA_ptr<NodeInterface> node = nodeIter->currentDUGNode();
    node->longdump(os, ir);
    os << endl;
  }
  
  os << "====================" << endl;

}

void
DUGStandard::dumpdot(ostream& os, OA_ptr<DUGIRInterface> ir)
{

  
  assert(0);  
  
  /*! commented out by PLM 100106
  os << "digraph OA_DUG {" << endl;
  os << "node [shape=rectangle];" << endl;

  // then output nodes and edges by procedure
  std::list<OA_ptr<Edge> >::iterator iter;
  for (iter=mEdges->begin(); iter!=mEdges->end(); iter++ ) {
    OA_ptr<Edge> edge = *iter;
    OA_ptr<Node> srcNode  = edge->source();
    OA_ptr<Node> sinkNode = edge->sink();

    OA_ptr<Location> srcLoc  = srcNode->getLoc();
    OA_ptr<Location> sinkLoc = sinkNode->getLoc();
    srcLoc->dump(os, mIR); 
    os << "_" << srcNode->getId();
    os << "->";
    sinkLoc->dump(os, mIR);
    os << "_" << sinkNode->getId();

    EdgeType etype = edge->getType();
    os << "[label=\"" << sEdgeTypeToString[etype] << "_";
    CallHandle call = edge->getCall();
    if (call != CallHandle(0)){
      SymHandle calleesym = ir->getSymHandle(call);
      os << mIR->toString(calleesym);
      os << "\\l" << (unsigned)edge->getCall().hval() << "\"];" << endl;
    }
    else{
      ProcHandle proc = sinkNode->getProc();
      os << mIR->toString(proc);
      os << "\"];" << endl;
    }
  }

  os << "}" << endl;
  os.flush();
  */
}

OA_ptr<Node> 
DUGStandard::getNode(SymHandle sym, ProcHandle proc){
  assert(sym);


  OA_ptr<Node> retval = mSymToNode[sym];
  
  /*
  if (retval.ptrEqual(0)){
      
    OA_ptr<NamedLoc> nmloc = loc.convert<NamedLoc>();
    OA_ptr<SymHandleIterator> overlapIter = nmloc->getFullOverlapIter();
    std::cout << "getNode(" << mIR->toString(sym) << "): ";
    for ( ; overlapIter->isValid() && retval.ptrEqual(0); (*overlapIter)++ ) {
      SymHandle tmpSym = overlapIter->current();
      retval = mSymToNode[tmpSym];

      ProcHandle tmpProc = mSymToProc[tmpSym];
      
      // PLM 2/11/07
      //OA_ptr<Location> tmpLoc = mIR->getLocation(tmpProc, tmpSym);
      

      OA_ptr<Location> tmpLoc;
      OA::OA_ptr<OA::MemRefExpr> symMRE = mIR->convertSymToMemRefExpr(sym);
      OA::OA_ptr<OA::LocIterator> symMRElocs_I = mAlias->getAliasResults(proc)->getMayLocs(*symMRE,proc);
      for ( ; symMRElocs_I->isValid(); (*symMRElocs_I)++ ) {
            tmpLoc = symMRElocs_I->current();
      }


      // mapping between all pairs of syms to Locs
      mSymToLoc[tmpSym] = tmpLoc;
      std::cout << mIR->toString(overlapIter->current()) << ", ";
    }
    std::cout << std::endl;
  }

  if (retval.ptrEqual(0)){
      
    OA_ptr<NamedLoc> nmloc = loc.convert<NamedLoc>();
    OA_ptr<SymHandleIterator> overlapIter = nmloc->getPartOverlapIter();
    for ( ; overlapIter->isValid() && retval.ptrEqual(0); (*overlapIter)++ ) {
      SymHandle tmpSym = overlapIter->current();
      retval = mSymToNode[tmpSym];

      ProcHandle tmpProc = mSymToProc[tmpSym];

      // PLM 2/11/07
      //OA_ptr<Location> tmpLoc = mIR->getLocation(tmpProc, tmpSym);

      OA_ptr<Location> tmpLoc;
      OA::OA_ptr<OA::MemRefExpr> symMRE = mIR->convertSymToMemRefExpr(sym);
      OA::OA_ptr<OA::LocIterator> symMRElocs_I = mAlias->getAliasResults(proc)->getMayLocs(*symMRE,proc);
      for ( ; symMRElocs_I->isValid(); (*symMRElocs_I)++ ) {
            tmpLoc = symMRElocs_I->current();
      }

      // mapping between all pairs of syms to Locs
      mSymToLoc[tmpSym] = tmpLoc;
    }
  }
  */

  if (retval.ptrEqual(0)){

    OA_ptr<DUGStandard> temp; temp = this;
    retval = new Node(temp, proc, sym);

//    std::cout << "The ProcHandle is :" << mIR->toString(proc) << std::endl;
//    std::cout << "The Symandle is:" << mIR->toString(sym) << std::endl;

    assert(!retval.ptrEqual(0));
    mSymToNode[sym] = retval;
    addNode(retval);
#ifdef DEBUG_DUAA
    std::cout << "added" << std::endl;
#endif
  }
#ifdef DEBUG_DUAA
  else {
    std::cout << "found" << std::endl;
  }
#endif

  return retval;
}

// true if a node exists for 'loc'
bool
DUGStandard::isNode(SymHandle sym, ProcHandle proc){
  assert(sym);
  OA_ptr<Node> retval = mSymToNode[sym];

  /*
  OA_ptr<Location> loc = mIR->getLocation(proc, sym);

  if (retval.ptrEqual(0)){
    OA_ptr<NamedLoc> nmloc = loc.convert<NamedLoc>();
    OA_ptr<SymHandleIterator> overlapIter = nmloc->getFullOverlapIter();
    std::cout << "getNode(" << mIR->toString(sym) << "): ";
    for ( ; overlapIter->isValid() && retval.ptrEqual(0); (*overlapIter)++ ) {
      SymHandle tmpSym = overlapIter->current();
      retval = mSymToNode[tmpSym];

      ProcHandle tmpProc = mSymToProc[tmpSym];

     //  PLM 2/11/07
     // OA_ptr<Location> tmpLoc = mIR->getLocation(tmpProc, tmpSym);

      OA_ptr<Location> tmpLoc;
      OA::OA_ptr<OA::MemRefExpr> symMRE = mIR->convertSymToMemRefExpr(sym);
      OA::OA_ptr<OA::LocIterator> symMRElocs_I = mAlias->getAliasResults(proc)->getMayLocs(*symMRE,proc);
      for ( ; symMRElocs_I->isValid(); (*symMRElocs_I)++ ) {
            tmpLoc = symMRElocs_I->current();
      }

      // mapping between all pairs of syms to Locs
      mSymToLoc[tmpSym] = tmpLoc;
      std::cout << mIR->toString(overlapIter->current()) << ", ";
    }
  }

  if (retval.ptrEqual(0)){
      
    OA_ptr<NamedLoc> nmloc = loc.convert<NamedLoc>();
    OA_ptr<SymHandleIterator> overlapIter = nmloc->getPartOverlapIter();
    
    for ( ; overlapIter->isValid() && retval.ptrEqual(0); (*overlapIter)++ ) {
      SymHandle tmpSym = overlapIter->current();
      retval = mSymToNode[tmpSym];

      ProcHandle tmpProc = mSymToProc[tmpSym];
      OA_ptr<Location> tmpLoc = mIR->getLocation(tmpProc, tmpSym);

      // mapping between all pairs of syms to Locs
      mSymToLoc[tmpSym] = tmpLoc;
    }
  }
*/
  
  return !retval.ptrEqual(0);
}

void 
DUGStandard::insertActiveSymSet(OA_ptr<Location> loc)
{
  // Unknown
  if (loc->isaUnknown()) {

    mUnknownLocActive = true;

    // Named
  } else if (loc->isaNamed()) {
      
    OA_ptr<NamedLoc> nloc = loc.convert<NamedLoc>();
#ifdef DEBUG_DUAA
    std::cout << "DUGStandard::insertActiveSymSet:(loc)"; 
    loc->dump(std::cout, mIR);
    std::cout << std::endl;
#endif  
    insertActiveSymSet( nloc->getSymHandle() );

    OA_ptr<SymHandleIterator> symIter = nloc->getFullOverlapIter();
    for ( ; symIter->isValid(); (*symIter)++) {
#ifdef DEBUG_DUAA
      std::cout << "\tFullOverlap: " << mIR->toString(symIter->current()); 
      std::cout << std::endl;
#endif  
      insertActiveSymSet( symIter->current());
    }
    symIter = nloc->getPartOverlapIter();
    for ( ; symIter->isValid(); (*symIter)++) {
#ifdef DEBUG_DUAA
      std::cout << "\tPartialOverlap: "; 
      std::cout << std::endl;
#endif  
      insertActiveSymSet(symIter->current());
    }
 
    // Unnamed
  } else if (loc->isaUnnamed()) {
    
     // std::cout << "Inside Unnamed Location" << std::endl;  
      
    //assert(0);
    // not handling this yet

    // Invisible
  } else if (loc->isaInvisible()) {

    OA_ptr<InvisibleLoc> invLoc 
      = loc.convert<InvisibleLoc>();
    OA_ptr<MemRefExpr> mre = invLoc->getMemRefExpr();

    // get symbol from memory reference expression if no derefs
    // FIXME: here need another visitor for MemRefExpr, for now assuming
    // only named ones
    if (mre->isaNamed()) {
      OA_ptr<NamedRef> namedRef 
        = namedRef.convert<NamedRef>();
      insertActiveSymSet( namedRef->getSymHandle() );
    } else {
      assert(0);
    }

    // LocSubSet
  } else if (loc->isaSubSet()) {

    OA_ptr<Location> baseLoc = loc->getBaseLoc();
    // FIXME: now really want to call visitor on this guy but instead will just
    // call this function recursively
    insertActiveSymSet(baseLoc);

  } else {

    assert(0);
  }
}


void 
Node::setActive(SymHandle sym)
{
  assert(mProc);
  // will be storing activity results for stmt and memrefs in
  // ActiveStandard for current procedure
  if (mDUG->mActiveMap[mProc].ptrEqual(0)) {
    mDUG->mActiveMap[mProc] = new OA::Activity::ActiveStandard(mProc);
  }

  mDUG->insertActiveSymSet(sym);

  std::set<MemRefHandle> mrefSet;
  mrefSet = mDUG->getMemRefSet(sym);
  if (!mrefSet.empty()){
       std::set<MemRefHandle>::iterator i = mrefSet.begin();
       for(; i != mrefSet.end(); i++) {
           mDUG->insertActiveMemRefSet(*i, mProc);
       }
  }


  std::set<StmtHandle> stmtSet;
  stmtSet = mDUG->getStmtSet(sym);
  if (!stmtSet.empty()){
    std::set<StmtHandle>::iterator i = stmtSet.begin();
    for(; i != stmtSet.end(); i++)
      mDUG->insertActiveStmtSet(*i, mProc);
  }

}


void 
Node::setActive()
{
  setActive(mSym);
}


void 
Node::markVaried(std::list<CallHandle>& callStack,
                              OA_ptr<Activity::ActivityIRInterface> ir,
                              std::set<OA_ptr<EdgeInterface> >& visited,
                              std::set<unsigned>& onPath,
                              ProcHandle proc,
                              unsigned prevId, 
                              OA_ptr<EdgeInterface> parenEdge)
{ 

  std::set<unsigned>::iterator pIter;
  for (pIter=onPath.begin(); pIter!=onPath.end(); pIter++ ) {
    unsigned in = *pIter;
  }  

  
  unsigned currId = getId();

  EdgeType parenEType = CFLOW_EDGE;
  CallHandle parenCall = CallHandle(0);
  if (!parenEdge.ptrEqual(0)) {
    parenEType = parenEdge->getType();
    parenCall = parenEdge->getCall();
  }


#ifdef DEBUG_DUAA_LAST
  std::cout << "-v->"; 
  OA_ptr<Location> loc = getLoc();
  loc->dump(std::cout, mDUG->mIR);
  std::cout << "(" << getId() << ")" << std::endl;
#endif  
  bool isVariedBefore = isVaried();
  setVaried();
  int nonParentSuccessors = 0;


  bool valueThroughGlobals = false;
  if (callStack.front() == CallHandle(1)) 
    valueThroughGlobals = true;

  // set up iterator for successor edges
  OA_ptr<EdgesIteratorInterface> succIterPtr;
  succIterPtr = getDUGOutgoingEdgesIterator();
  // iterate over the successors
  for (; succIterPtr->isValid(); ++(*succIterPtr)) {

    OA_ptr<EdgeInterface> succEdge = succIterPtr->currentDUGEdge();
    OA_ptr<NodeInterface> succNode = succEdge->getDUGSink();

    OA_ptr<Node> sn = succNode.convert<Node>();

    SymHandle s = sn->getSym();

    unsigned succId = succNode->getId();

    if (succId != prevId || parenCall != succEdge->getCall()) nonParentSuccessors++;

    if (visited.find(succEdge) != visited.end() ||
        onPath.find(succId)    != onPath.end()  ) 
    {
        continue;
    }

    onPath.insert(succId);
    EdgeType etype = succEdge->getType();

#ifdef DEBUG_DUAA_LAST
    if (succEdge->getType() != RETURN_EDGE || 
        callStack.front() == succEdge->getCall() || valueThroughGlobals){
      OA_ptr<Location> loc = getLoc();
      loc->dump(std::cout, mDUG->mIR);
      std::cout << "(" << getId() << ":" << sEdgeTypeToString[etype];
      CallHandle call = succEdge->getCall();
      if (call != CallHandle(0)){
        SymHandle calleesym = ir->getSymHandle(call);
        std::cout << ":" << mDUG->mIR->toString(calleesym);
        std::cout << ":" << (unsigned)succEdge->getCall().hval();
      }
      else {
        std::cout << ":" << mDUG->mIR->toString(succEdge->getProc());
      }
      std::cout << ")";
    }
#endif  
    switch(etype) {
      case (CALL_EDGE):
        callStack.push_front(succEdge->getCall());
        visited.insert(succEdge);
        
        succNode->markVaried(callStack, ir, visited, onPath, 
                             succEdge->getSinkProc(), currId, 
                             succEdge);
        callStack.pop_front();
        break;
      case (RETURN_EDGE):
        if (callStack.front() == succEdge->getCall() || valueThroughGlobals){
          if (!valueThroughGlobals) callStack.pop_front();
          visited.insert(succEdge);

          succNode->markVaried(callStack, ir, visited, onPath, 
                               succEdge->getProc(), currId, 
                               succEdge);
          if (!valueThroughGlobals) callStack.push_front(succEdge->getCall());
        }
#ifdef DEBUG_DUAA_LAST
        else{
          //std::cout << "markVaried: " << (callStack.front() == succEdge->getCall())
                    << (unsigned)callStack.front().hval() << "<->"
                    << (unsigned)succEdge->getCall().hval() << std::endl;
        }
#endif  
        break;
      default: // for both CFLOW_EDGE and PARAM_EDGE
        if (succEdge->getType() != PARAM_EDGE) 
          visited.insert(succEdge);
        // to prevent value passing through global variables between procedures
        ProcHandle succProc = succEdge->getProc();
        if (proc != succProc) {
          callStack.push_front(CallHandle(1));
          
          succNode->markVaried(callStack, ir, visited, onPath, 
                               succProc, currId, succEdge);
          callStack.pop_front();
        }
        else{
          succNode->markVaried(callStack, ir, visited, onPath, 
                               proc, currId, succEdge);
        }
#if 0
        else
        {
          std::cout << "-v->"; 
          OA_ptr<Location> loc = succNode->getLoc();
          loc->dump(std::cout, mDUG->mIR);
          std::cout << "(" << succNode->getId() << "): ";
          std::cout << mDUG->mIR->toString(proc) << "<->" 
                    << mDUG->mIR->toString(succEdge->getProc()) <<std::endl;
        }
#endif  
          
        break;
    }

    onPath.erase(succId);
  }

  // Actual or formal parameters without any outgoing edges shouldn't be
  // activated.
  if (nonParentSuccessors == 0 && !isVariedBefore && !isSelfDependent() && 
      ( parenEType == CALL_EDGE || parenEType == RETURN_EDGE) && 
      !mDUG->isDependent(getSym()) ){
    unsetVaried();

#ifdef DEBUG_DUAA_LAST
  std::cout << "unsetVaried" << std::endl;
#endif  
  }
#ifdef DEBUG_DUAA_LAST
  std::cout << "<-" << std::endl;
#endif  
}

void
Node::markUseful(std::list<CallHandle>& callStack,
                              OA_ptr<Activity::ActivityIRInterface> ir,
                              std::set<OA_ptr<EdgeInterface> >& visited,
                              std::set<unsigned>& onPath,
                              ProcHandle proc,
                              unsigned prevId, 
                              OA_ptr<EdgeInterface> parenEdge)
{
   
  if (!isVaried()) {
      return;
  }
  unsigned currId = getId();

  EdgeType parenEType = CFLOW_EDGE;
  CallHandle parenCall = CallHandle(0);
  if (!parenEdge.ptrEqual(0)) {
    parenEType = parenEdge->getType();
    parenCall = parenEdge->getCall();
  }

#ifdef DEBUG_DUAA_LAST
  std::cout << "-u->"; 
  OA_ptr<Location> loc = getLoc();
  loc->dump(std::cout, mDUG->mIR);
  std::cout << "(" << getId() << ")" << std::endl;
#endif  
  bool isUsefulBefore = isUseful();
  setUseful();
  int nonChildAncestors = 0;

  bool valueThroughGlobals = false;
  if (callStack.front() == CallHandle(1)) {
    valueThroughGlobals = true;
#ifdef DEBUG_DUAA_LAST
   // std::cout << "val thru globals" << std::endl;
#endif  
  }

#ifdef DEBUG_DUAA_LAST
  bool display = false;
  if ((!strncmp(mDUG->mIR->toString(getSym()).c_str(), "vfld", 4) ||
       !strncmp(mDUG->mIR->toString(getSym()).c_str(), "VFLD", 4)) &&
      (!strncmp(mDUG->mIR->toString(proc).c_str(), "mom_v_adv_wv", 12) ||
       !strncmp(mDUG->mIR->toString(proc).c_str(), "MOM_V_ADV_WV", 12))){
//     std::cout << "MOM_V_ADV_WV: " << mDUG->mIR->toString(getSym()) << std::endl;
    display = true;
  }
#endif

  // set up iterator for predecessor edges
  OA_ptr<EdgesIteratorInterface> predIterPtr;
  predIterPtr = getDUGIncomingEdgesIterator();
  // iterate over the predecessors
  for (; predIterPtr->isValid(); ++(*predIterPtr)) {
      
    OA_ptr<EdgeInterface> predEdge = predIterPtr->currentDUGEdge();
    OA_ptr<NodeInterface> predNode = predEdge->getDUGSource();
    unsigned predId = predNode->getId();
#ifdef DEBUG_DUAA_LAST
    if (display){
      std::cout << "CONTINUE: visited(" << (visited.find(predEdge) != visited.end()) 
                << "), path(" << (onPath.find(predId) != onPath.end()) << ")" << std::endl;
    }
#endif  
    if (predId != prevId || parenCall != predEdge->getCall()) nonChildAncestors++;
    if (visited.find(predEdge) != visited.end() ||
        onPath.find(predId)    != onPath.end()  ) continue;
    onPath.insert(predId);
    EdgeType etype = predEdge->getType();

#ifdef DEBUG_DUAA_LAST
    if (predEdge->getType() != CALL_EDGE || 
        callStack.front() == predEdge->getCall() || valueThroughGlobals){
      OA_ptr<Location> loc = getLoc();
      loc->dump(std::cout, mDUG->mIR);
      std::cout << "(" << getId() << ":" << sEdgeTypeToString[etype];
      CallHandle call = predEdge->getCall();
      if (call != CallHandle(0)){
        SymHandle calleesym = ir->getSymHandle(call);
        std::cout << mDUG->mIR->toString(calleesym);
      }
      std::cout << ":" << (unsigned)predEdge->getCall().hval() << ")";
    }
#endif  
    switch(etype) {
      case (CALL_EDGE):
        if (callStack.front() == predEdge->getCall() || valueThroughGlobals ){
          if (!valueThroughGlobals) callStack.pop_front();
          visited.insert(predEdge);
          predNode->markUseful(callStack, ir, visited, onPath, 
                               predEdge->getProc(), currId, predEdge);
          if (!valueThroughGlobals) callStack.push_front(predEdge->getCall());
        }
        break;
      case (RETURN_EDGE):
        callStack.push_front(predEdge->getCall());
        visited.insert(predEdge);
        predNode->markUseful(callStack, ir, visited, onPath, 
                             predEdge->getSourceProc(), 
                             currId, predEdge);
        callStack.pop_front();
        break;
      default: // for both CFLOW_EDGE and PARAM_EDGE
        if (predEdge->getType() != PARAM_EDGE) visited.insert(predEdge);
        ProcHandle predProc = predEdge->getProc();
        if (proc != predProc) {
          callStack.push_front(CallHandle(1));
#ifdef DEBUG_DUAA_LAST
          std::cout << "valthruglobals: begin" << std::endl;
#endif  
          predNode->markUseful(callStack, ir, visited, onPath, 
                               predProc, currId, predEdge);
          callStack.pop_front();
#ifdef DEBUG_DUAA_LAST
          std::cout << "valthruglobals: end" << std::endl;
#endif  
        }
        else
        {
          predNode->markUseful(callStack, ir, visited, onPath, 
                               proc, currId, predEdge);
        }
        break;
    }

    onPath.erase(predId);
  }

#ifdef DEBUG_DUAA_LAST
  if (display)
    printf("VFLD: %d, %d, %d\n", nonChildAncestors, getType(), isUsefulBefore);
#endif  
  // Formal parameters without any outgoing edges shouldn't be
  // activated.
  if (nonChildAncestors == 0 && !isUsefulBefore && !isSelfDependent() && 
      ( parenEType == RETURN_EDGE || parenEType == CALL_EDGE) &&
      !mDUG->isIndependent(getSym()) ){
    //  std::cout << "**** just before unsetUseful ****" << std::endl;
    unsetUseful();
  }else{
     // std::cout << "**** just before setActive ****" << std::endl;  
    setActive();
  }
//  std::cout << "**** after setActive *****" << std::endl;
#ifdef DEBUG_DUAA_LAST
  std::cout << "<-" << std::endl;
#endif  
}

//! Indicate whether the given sym is active or not
bool DUGStandard::isActive(SymHandle sym)
{
  // an unknown location is active, therefore all symbols are active
  if (mUnknownLocActive) {
    return true;
  } else if (mActiveSymSet->find(sym) != mActiveSymSet->end()) {
    return true;
  } else {
    return false;
  }  
}



//! Indicate whether the given memref is active or not
bool DUGStandard::isActive(MemRefHandle memref)
{
  if (mActiveMemRefSet->find(memref) != mActiveMemRefSet->end()) {
    return true;
  } else {
    return false;
  }
}



// 'true' if there is a path from 'useNode' to 'this'
bool
Node::isPathFrom(OA_ptr<NodeInterface> useNode,
                              std::set<OA_ptr<NodeInterface> >& visited)
{ 
  if (useNode.ptrEqual(this)) return true;

  // traverse backward from this nodes
  OA_ptr<EdgesIteratorInterface> predIterPtr
    = getDUGIncomingEdgesIterator();
  for (; predIterPtr->isValid(); ++(*predIterPtr)) {
    OA_ptr<EdgeInterface> predEdge = predIterPtr->currentDUGEdge();
    OA_ptr<NodeInterface> predNode = predEdge->getDUGSource();
  
    if (visited.find(predNode) != visited.end()) continue;
    visited.insert(predNode);
    if (predNode->isPathFrom(useNode, visited)) return true;
  }

  return false;
}



// true if this has an outgoing edge to other procedures
bool
Node::hasOutgoingEdgesToOtherProcs(ProcHandle proc)
{ 
  OA_ptr<EdgesIteratorInterface> succIterPtr
    = getDUGOutgoingEdgesIterator();
  for (; succIterPtr->isValid(); ++(*succIterPtr)) {
    OA_ptr<EdgeInterface> succEdge = succIterPtr->currentDUGEdge();
    if (succEdge->getType() != CFLOW_EDGE) continue;
    if (succEdge->getProc() != proc) return true;
  }

  return false;
}



// returns a set of outgoing nodes of this proc
void
Node::findOutgoingNodes(ProcHandle proc, 
                                     std::set<SymHandle>& OutGoingNodeSet,
                                     std::set<SymHandle>& visited)
{ 
  SymHandle sym = getSym();
  if (visited.find(sym) != visited.end()) return;
  visited.insert(sym);

  if (hasOutgoingEdgesToOtherProcs(proc)) 
    OutGoingNodeSet.insert(sym);

  // traverse foreward from this nodes
  OA_ptr<EdgesIteratorInterface> succIterPtr
    = getDUGOutgoingEdgesIterator();
  for (; succIterPtr->isValid(); ++(*succIterPtr)) {
    OA_ptr<EdgeInterface> succEdge = succIterPtr->currentDUGEdge();
    OA_ptr<NodeInterface> succNode = succEdge->getDUGSink();

    if (succEdge->getType() != CFLOW_EDGE) continue;
    if (succEdge->getProc() != proc) continue;
  
    succNode->findOutgoingNodes(proc, OutGoingNodeSet, visited);
  }
}



// true if this has an incoming edge to other procedures
bool
Node::hasIncomingEdgesFromOtherProcs(ProcHandle proc)
{ 
  OA_ptr<EdgesIteratorInterface> predIterPtr
    = getDUGIncomingEdgesIterator();
  for (; predIterPtr->isValid(); ++(*predIterPtr)) {
    OA_ptr<EdgeInterface> predEdge = predIterPtr->currentDUGEdge();
    if (predEdge->getType() != CFLOW_EDGE) continue;
    if (predEdge->getProc() != proc) return true;
  }

  return false;
}



// returns a set of incoming nodes of this proc
void
Node::findIncomingNodes(ProcHandle proc, 
                                     std::set<SymHandle>& InComingNodeSet,
                                     std::set<SymHandle>& visited)
{ 
  SymHandle sym = getSym();
  if (visited.find(sym) != visited.end()) return;
  visited.insert(sym);

  if (hasIncomingEdgesFromOtherProcs(proc)) 
    InComingNodeSet.insert(sym);

  // traverse backward from this nodes
  OA_ptr<EdgesIteratorInterface> predIterPtr
    = getDUGIncomingEdgesIterator();
  for (; predIterPtr->isValid(); ++(*predIterPtr)) {
    OA_ptr<EdgeInterface> predEdge = predIterPtr->currentDUGEdge();
    OA_ptr<NodeInterface> predNode = predEdge->getDUGSource();
  
    if (predEdge->getType() != CFLOW_EDGE) continue;
    if (predEdge->getProc() != proc) continue;

    predNode->findIncomingNodes(proc, InComingNodeSet, visited);
  }
}



  } // end namespace DUGStandard
} // end namespace OA
