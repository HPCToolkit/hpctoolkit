#ifndef DataDepInterface_H
#define DataDepInterface_H

// Rename to DataDepIRInterface and put in IRInterfaces/ package !!!
namespace OA {
namespace DataDep {


    // getExprTree(ExprHandle h)
} } // end namespaces

#endif

