#ifndef LoopInterface_H
#define LoopInterface_H

#include <IRInterface/IRHandles.hpp>
#include <list>
using namespace std;

namespace OA {

class Interface {
  public:
    Interface() {}
    virtual ~Interface() {}
    
    LoopIterator getLoopIterator();

  private:
    list<Loop> mLoops;
};


} // namespaces

#endif

