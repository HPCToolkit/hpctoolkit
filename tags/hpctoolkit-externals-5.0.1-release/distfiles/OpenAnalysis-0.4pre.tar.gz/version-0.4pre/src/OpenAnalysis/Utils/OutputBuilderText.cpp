/*! \file
  
  \brief Definitions for OutputBuilder for text output
  
  \authors Michelle Strout, Andy Stone
  \version $Id: OutputBuilderText.cpp,v 1.3 2005/01/18 21:13:16 mstrout Exp $

  Copyright (c) 2002-2005, Rice University <br>
  Copyright (c) 2004-2005, University of Chicago <br>
  Copyright (c) 2006, Contributors <br>
  All rights reserved. <br>
  See ../../../Copyright.txt for details. <br>
*/

#include "OutputBuilderText.hpp"

namespace OA {

int gNestedObjects = 0;
int gIndentLevel = 0;
ostream &indt(ostream &os)
{
    os << '\n';
    os.flush();
    for(int i = 0; i < gIndentLevel; i++) { os << "    "; }
    return os;
}

ostream &pushIndt(ostream &os)
{
    gIndentLevel++;
    return os;
}

ostream &popIndt(ostream &os) 
{
    gIndentLevel--;
    return os;
}

void OutputBuilderText::outputString(const std::string &str)
{
    mStream << str;
}

//*****************************************************************
// IRHandles
//*****************************************************************
void OutputBuilderText::outputIRHandle(ProcHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "ProcHandle(" << pIR.toString(h) << ")";
}

void OutputBuilderText::outputIRHandle(StmtHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "StmtHandle(" << pIR.toString(h) << ")";
}

void OutputBuilderText::outputIRHandle(ExprHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "ExprHandle(" << pIR.toString(h) << ")";
}

void OutputBuilderText::outputIRHandle(CallHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "CallHandle(" << pIR.toString(h) << ")";
}

void OutputBuilderText::outputIRHandle(OpHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "OpHandle(" << pIR.toString(h) << ")";
}

void OutputBuilderText::outputIRHandle(MemRefHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "MemRefHandle(" << pIR.toString(h) << ")";
}

void OutputBuilderText::outputIRHandle(SymHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "SymHandle(" << pIR.toString(h) << ")";
}

void OutputBuilderText::outputIRHandle(ConstSymHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "ConstSymHandle(" << pIR.toString(h) << ")";
}

void 
OutputBuilderText::outputIRHandle(ConstValHandle h,
    IRHandlesIRInterface& pIR)
{
    mStream << "ConstValHandle(" << pIR.toString(h) << ")";
}

//*****************************************************************
// Objects
//*****************************************************************
void OutputBuilderText::objStart(const std::string& objName)
/*!
 * \param objName   Name of object class
 *
 * The start of each object increased object depth.
 */
{ 
    gNestedObjects++;
    mStream << indt << objName << "(" << pushIndt;
}

void OutputBuilderText::objEnd(const std::string& objName)
/*!
 * The end of each object decreases object depth.
 */
{ 
    gNestedObjects--;
    mStream << popIndt << indt << ")";
    
    // We want to output a newline character after the object is done.
    // We must insure that nested objects (caused by two or more calls to
    //  objStart without a call to objEnd) do not outline this newline char.
    if(gNestedObjects <= 0) {
        mStream << endl;
    }
}

void OutputBuilderText::field(const std::string& fieldname,
    const std::string& value)
{
    mStream << indt << fieldname << ": " << value; 
}

void OutputBuilderText::fieldStart(const std::string& fieldname) 
{
    mStream << indt << fieldname + ": "; 
}

void OutputBuilderText::fieldEnd(const std::string& fieldname) 
{
}
    
/*
void OutputBuilderText::fieldValue(const std::string& fieldvalue) 
{ 
    mStream << fieldvalue; 
}

void OutputBuilderText::fieldValueBegin() 
{}
    
void OutputBuilderText::fieldValueEnd() 
{}

void OutputBuilderText::fieldDelimit() 
{ mStream << ", "; }
*/

void OutputBuilderText::listStart() 
{ mStream << "[ " << pushIndt;  mListItemCount = 0; }

void OutputBuilderText::listEnd()   
{ mStream << " ] " << popIndt; }

void OutputBuilderText::listItem(const std::string& value) 
{ 
  if(mListItemCount>0) {mStream << "    "; }
  mStream << value; 
  mListItemCount++;
} 

void OutputBuilderText::listItemStart() 
{
  if(mListItemCount>0) {mStream << "    "; }
}

void OutputBuilderText::listItemEnd() 
{
  mListItemCount++;
}

//*****************************************************************
// Maps
//*****************************************************************
void OutputBuilderText::mapStart(const std::string& label,
                  const std::string& keyLabel,
                  const std::string& valueLabel)
{ 
  mStream << indt << label << ": " << keyLabel << "\t => " << valueLabel;
  mStream << pushIndt;
}

void OutputBuilderText::mapEnd(const std::string& label)   
{ 
//  mStream << popIndt;
    mStream << popIndt << std::endl;
}

void OutputBuilderText::mapEntry(const std::string& key, const std::string& value)
{ 
  mapEntryStart();
  mapKey(key);
  mapValue(value);
  mapEntryEnd();
} 

void OutputBuilderText::mapKey(const std::string& key)
{ 
  mapKeyStart();
  mStream << key;
  mapKeyEnd();
} 

void OutputBuilderText::mapValue(const std::string& value)
{ 
  mapValueStart();
  mStream << value;
  mapValueEnd();
} 


void OutputBuilderText::mapEntryStart() 
{
  mStream << pushIndt;
}

void OutputBuilderText::mapEntryEnd() 
{
  mStream << popIndt;
}

void OutputBuilderText::mapKeyStart() 
{
  mStream << indt;
}

void OutputBuilderText::mapKeyEnd() 
{
  mStream << "\t => ";
}

void OutputBuilderText::mapValueStart() 
{
}

void OutputBuilderText::mapValueEnd() 
{
}

//*****************************************************************
// Graphs
//*****************************************************************
void OutputBuilderText::graphStart(const std::string &label)
{
    mStream << indt << "graph " << label << ":" << std::endl << pushIndt;
}

void OutputBuilderText::graphEnd(const std::string &label)
{
    mStream << popIndt << std::endl;
}

void OutputBuilderText::graphSubStart(const std::string &label)
{
    mStream << indt << "subgraph " << label << ":" << std::endl << pushIndt;
}

void OutputBuilderText::graphSubEnd(const std::string &label)
{
    mStream << popIndt << std::endl;
}

void OutputBuilderText::graphNodeStart(int id)
{
    mStream << indt << "Node " << id << ": ";
}

void OutputBuilderText::graphNodeLabel(const std::string &label)
{
    mStream << label;
}

void OutputBuilderText::graphNodeLabelStart()
{
    mStream << pushIndt << indt;
}

void OutputBuilderText::graphNodeLabelEnd()
{
    mStream << popIndt;
}

void OutputBuilderText::graphNodeEnd()
{
    mStream << std::endl;
}

void OutputBuilderText::graphEdgeStart()
{
    mStream << indt << "Edge: ";
}

void OutputBuilderText::graphEdgeLabelStart()
{
    mStream << pushIndt << indt;
}

void OutputBuilderText::graphEdgeLabelEnd()
{
    mStream << popIndt;
}

void OutputBuilderText::graphEdgeSourceNode(int id)
{
    mStream << id << " => ";
}

void OutputBuilderText::graphEdgeSinkNode(int id)
{
    mStream << id;
}

void OutputBuilderText::graphEdgeEnd()
{
    mStream << std::endl;
}

} // end of OA namespace

