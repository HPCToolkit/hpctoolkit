int i = 4;

int
foo ()
{
  return i;
}
