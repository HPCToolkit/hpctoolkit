
.*:     file format elf32-.*arm

DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
.* R_ARM_TLS_DTPMOD32  \*ABS\*
.* R_ARM_TLS_DTPMOD32  lib_gd
.* R_ARM_TLS_DTPOFF32  lib_gd


