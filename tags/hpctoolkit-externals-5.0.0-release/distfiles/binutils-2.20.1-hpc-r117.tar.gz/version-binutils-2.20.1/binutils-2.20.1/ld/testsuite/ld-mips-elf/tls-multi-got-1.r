
Dynamic section at offset .* contains 18 entries:
  Tag        Type                         Name/Value
 0x00000004 \(HASH\)                       0x1c4
 0x00000005 \(STRTAB\).*
 0x00000006 \(SYMTAB\).*
 0x0000000a \(STRSZ\)                      220091 \(bytes\)
 0x0000000b \(SYMENT\)                     16 \(bytes\)
 0x00000003 \(PLTGOT\)                     0x122360
 0x00000011 \(REL\)                        0xa7978
 0x00000012 \(RELSZ\)                      160072 \(bytes\)
 0x00000013 \(RELENT\)                     8 \(bytes\)
 0x70000001 \(MIPS_RLD_VERSION\)           1
 0x70000005 \(MIPS_FLAGS\)                 NOTPOT
 0x70000006 \(MIPS_BASE_ADDRESS\)          0
 0x7000000a \(MIPS_LOCAL_GOTNO\)           2
 0x70000011 \(MIPS_SYMTABNO\)              20013
 0x70000012 \(MIPS_UNREFEXTNO\)            10
 0x70000013 \(MIPS_GOTSYM\)                0xd
 0x0000001e \(FLAGS\)                      STATIC_TLS
 0x00000000 \(NULL\)                       0x0

Relocation section '\.rel\.dyn' at offset 0x[0-9a-f]+ contains 20009 entries:
 Offset     Info    Type            Sym.Value  Sym. Name
[0-9a-f ]+R_MIPS_NONE      
[0-9a-f ]+R_MIPS_TLS_DTPMOD
[0-9a-f ]+R_MIPS_TLS_DTPMOD
[0-9a-f ]+R_MIPS_TLS_DTPMOD 00000000   tlsvar_gd
[0-9a-f ]+R_MIPS_TLS_DTPREL 00000000   tlsvar_gd
[0-9a-f ]+R_MIPS_TLS_DTPMOD 00000000   tlsvar_gd
[0-9a-f ]+R_MIPS_TLS_DTPREL 00000000   tlsvar_gd
[0-9a-f ]+R_MIPS_TLS_TPREL3 00000004   tlsvar_ie
[0-9a-f ]+R_MIPS_TLS_TPREL3 00000004   tlsvar_ie
[0-9a-f ]+R_MIPS_REL32      000d7f98   sym_1_9526
[0-9a-f ]+R_MIPS_REL32      000d65f4   sym_1_7885
#...
[0-9a-f ]+R_MIPS_REL32      000cf204   sym_1_0465
[0-9a-f ]+R_MIPS_REL32      000e0e48   sym_2_8654
