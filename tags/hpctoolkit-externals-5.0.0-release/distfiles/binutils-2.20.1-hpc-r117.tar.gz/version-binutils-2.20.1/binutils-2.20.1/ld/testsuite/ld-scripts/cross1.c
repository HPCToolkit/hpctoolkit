extern int foo ();
int
func ()
{
  return foo ();
}
