
tmpdir/arm-lib-plt32.so:     file format elf32-(little|big)arm

DYNAMIC RELOCATION RECORDS
OFFSET   TYPE              VALUE 
.* R_ARM_JUMP_SLOT   app_func2


